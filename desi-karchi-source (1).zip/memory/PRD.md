# Desi Karchi — PRD

## Original Problem Statement
"give me simple one page food dilivery web app name 'Desi Karchi' feature like payment gateway, add to cart, backend, order 24 hours before, only diliver in kalkaji 110019"

## User Choices
- Payment gateway: **PayU** (test mode; user will paste PAYU_KEY / PAYU_SALT later)
- No user accounts — guest checkout (name, phone, address)
- Owner adds own dishes via Owner Panel (PIN: 1234, footer "Owner login")
- Customer picks a delivery date/time slot at least 24 hours ahead

## Architecture
- **Frontend**: React (single page + /payment-result route), Tailwind + shadcn, warm copper/spice theme (Fraunces + Outfit fonts). Files: src/pages/HomePage.jsx, PaymentResult.jsx, components/{Header,Hero,MenuSection,DishCard,CartDrawer,CheckoutModal,AdminPanel}.jsx, context/CartContext.jsx, utils/slots.js, api.js
- **Backend**: FastAPI /app/backend/server.py, MongoDB (motor). Routes under /api: config, menu CRUD (PIN-gated), orders (server-side price calc, pincode + 24h IST slot validation), PayU start + success/failure callbacks (SHA-512 request/response hash verification, idempotent), payment-status polling
- **DB collections**: dishes, orders (indexed on payu_txnid)

## Implemented (16 Sep 2026)
- Brand logo integrated (header + favicon); full theme matched to logo palette (cream base, logo red primary, chocolate brown text, golden mustard accents, Baloo 2 display font)
- Dedicated admin panel page at /admin (PIN-gated): add dishes (name, price, category, image URL, veg toggle, spice level) and delete dishes from a live menu table; footer "Owner login" links to it; old modal-based AdminPanel removed
- PIN management: owner PIN changed to 4424; Change PIN card inside panel (requires current PIN, stored in db.settings); Forgot PIN recovery flow on login screen using recovery code 8842 (RECOVERY_CODE env); PIN validation 4–6 digits
- Admin Orders section: GET /api/admin/orders (PIN-gated) + orders list in /admin showing order id, payment status badge, customer name/phone/address, items with qty, delivery slot, amount
- Dish editing: PUT /api/menu/{id} (PIN-gated) + pencil edit button per dish row in /admin (form switches to edit mode with cancel)
- Owner auth upgraded to username+password login (POST /api/admin/login; username `owner`); "Admin" button in site header top-right opens the login page; Change password + Forgot password (recovery code) flows retained; old PIN endpoints removed (x-admin-pin header now carries the password)
- Owner email alerts (Resend managed integration, EMERGENT_EMAIL_KEY): order-created email (payment pending) + payment-confirmed email to desikarchi@gmail.com (OWNER_EMAIL env); fire-and-forget asyncio tasks, guardrail gate on every send, sender name "Desi Karchi", reply-to desikarchi@gmail.com
- Customer order emails: order-received + payment-confirmed emails sent to the customer's email (now required at checkout, validated client + server side); customer replies land at desikarchi@gmail.com via reply-to
- Swiggy-style theme: signature orange #FC8019 primary, white background, dark blue-grey text, green accents, Nunito display font
- Editable site content: GET /api/content (public, DB overrides merged over defaults) + PUT /api/content (owner-gated); "Site text" editor in /admin covers header tagline/badges, hero badge/title/subtitle, pincode widget, menu headings, how-it-works steps, footer (defaults in /app/frontend/src/contentDefaults.js)
- Owner-managed delivery pincodes: db.settings.delivery_pincodes (default ["110019"]), PUT /api/admin/pincodes (owner-gated, 6-digit validation, at least one required); GET /api/config returns pincodes; hero pincode checker, checkout validation, cart delivery line and backend order validation all read the live list; admin "Delivery pincodes" section with add/remove chips
- Order fulfillment statuses: paid orders start at order_received (was "confirmed"); owner advances via PUT /api/admin/orders/{id}/status to prepared / out_for_delivery / delivered (Select control on each paid order row in /admin); status badges color-coded
- Customer order tracking: /track page (header "Track order" button + auto-linked from payment confirmation) — order ID (full or 8-char prefix) + phone verified server-side (GET /api/orders/{id}/track?phone=); shows status timeline, items, amount, slot; no address/PII exposed
- Owner-set delivery charge: db.settings.delivery_charge (default 0 = free), PUT /api/admin/delivery-charge (owner-gated, 0–500); backend adds it to every order total (subtotal + delivery_charge stored on order); cart drawer, checkout summary and Pay button show live charge; control lives in admin "Delivery pincodes" section
- Dish image upload from device: Emergent object storage (EMERGENT_LLM_KEY, app prefix `desikarchi`), POST /api/upload (owner-password gated, JPG/PNG/WEBP/GIF, max 5MB) → public serving via GET /api/files/{path} with DB file records (soft-delete pattern); admin form has "Upload image" device picker with instant preview, URL paste still supported as fallback
- PayU test keys configured; live sandbox payment verified end-to-end (callback hash fix + idempotency, 14/14 backend tests incl. dedicated PayU callback suite)
- Menu grid with category tabs, veg-only toggle, spice indicators, qty steppers
- Cart drawer with localStorage persistence, bill breakdown, free delivery
- Guest checkout modal with validation (phone, address, pincode == 110019)
- Delivery slot picker: next 7 days, slots filtered to >= 24h ahead (IST-aware on both client & server)
- Owner Panel (PIN 1234): add/delete dishes, live menu list
- PayU hosted checkout integration (test endpoint), secure server-side hashing, callback verification + redirect to /payment-result
- Payment result page with status polling + order confirmation details
- Pincode validator widget in hero
- Seed menu of 6 sample dishes (only seeds when menu empty; owner can delete)
- Backend test suite: /app/backend/tests/backend_test.py (10 tests, all pass)

## Known State / Blockers
- **PayU is LIVE (production)** — endpoint https://secure.payu.in/_payment, live key/salt configured (16 Sep 2026). Real money is charged. Test-mode rollback values are stored in /app/memory/test_credentials.md.
- Owner PIN is a simple shared secret (fine for MVP, no user auth by request).

## Backlog
- P0: Add PayU test keys → verify live PayU redirect + callback end-to-end; go-live switch to secure.payu.in
- P1: Owner view of incoming orders (list confirmed orders in Owner Panel)
- P1: Order status updates (preparing / out for delivery / delivered) + customer order lookup by phone
- P2: SMS/WhatsApp order confirmation, delivery fee config, dish images via upload (object storage), discount coupons
