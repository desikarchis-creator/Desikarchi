# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.

## Desi Karchi — Owner Panel
- Access: "Admin" button in the top-right site header, or direct URL /admin
- Login: username `owner`, password `6245` (migrated from PIN; runtime password lives in db.settings.admin_password, overrides env ADMIN_PASSWORD)
- Recovery code (Forgot password flow): `8842` (backend/.env RECOVERY_CODE)

## PayU Payment Gateway
- Mode: **LIVE** (endpoint https://secure.payu.in/_payment) — real money is charged. Live key/salt are configured in /app/backend/.env (16 Sep 2026).
- Test-mode rollback values (if ever needed): endpoint https://test.payu.in/_payment, key zmSwgE, salt 9AzoLt9b04BcF7etMBpnZqc5BqOF13Ob
- Test card 5123456789012346 only works in test mode — DO NOT use for live payments.
