import "@/App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { CartProvider } from "@/context/CartContext";
import HomePage from "@/pages/HomePage";
import PaymentResult from "@/pages/PaymentResult";
import AdminPage from "@/pages/AdminPage";
import TrackOrder from "@/pages/TrackOrder";

function App() {
  return (
    <div className="App">
      <CartProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/payment-result" element={<PaymentResult />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/track" element={<TrackOrder />} />
          </Routes>
        </BrowserRouter>
        <Toaster position="top-center" richColors />
      </CartProvider>
    </div>
  );
}

export default App;
