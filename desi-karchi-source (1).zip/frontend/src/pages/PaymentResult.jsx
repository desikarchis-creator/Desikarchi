import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { CheckCircle2, Clock, Loader2, XCircle } from "lucide-react";
import { getOrder, getPaymentStatus } from "@/api";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";

export default function PaymentResult() {
  const [params] = useSearchParams();
  const orderId = params.get("order_id");
  const [status, setStatus] = useState("loading");
  const [order, setOrder] = useState(null);
  const { clear } = useCart();

  useEffect(() => {
    if (!orderId) return setStatus("missing");
    let tries = 0;
    const poll = async () => {
      try {
        const s = await getPaymentStatus(orderId);
        if (s.payment_status === "success") {
          setStatus("success");
          clear();
          getOrder(orderId).then(setOrder).catch(() => {});
          return;
        }
        if (s.payment_status === "failure") return setStatus("failure");
        if (++tries < 8) setTimeout(poll, 2500);
        else setStatus("pending");
      } catch {
        setStatus("missing");
      }
    };
    poll();
  }, [orderId, clear]);

  return (
    <div data-testid="payment-result-page" className="flex min-h-screen items-center justify-center bg-background px-5">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-10 text-center shadow-sm animate-fade-up">
        {status === "loading" && (
          <>
            <Loader2 className="mx-auto h-12 w-12 animate-spin text-primary" />
            <h1 className="mt-5 font-display text-2xl font-bold">Confirming your payment…</h1>
            <p className="mt-2 text-sm text-muted-foreground">Please wait while PayU confirms.</p>
          </>
        )}
        {status === "success" && (
          <>
            <CheckCircle2 data-testid="payment-success-icon" className="mx-auto h-14 w-14 text-green-600" />
            <h1 className="mt-5 font-display text-3xl font-bold">Order confirmed!</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Your kadhai is booked. We'll cook fresh and deliver in your chosen slot.
            </p>
            {order && (
              <div data-testid="order-confirmation-details" className="mt-6 space-y-2 rounded-2xl border border-border bg-background p-5 text-left text-sm">
                <p><span className="text-muted-foreground">Order ID:</span> <span data-testid="order-id-value" className="font-mono font-semibold">{order.id.slice(0, 8).toUpperCase()}</span></p>
                <p><span className="text-muted-foreground">Deliver to:</span> {order.customer.name}, {order.customer.address}, {order.customer.pincode}</p>
                <p><span className="text-muted-foreground">Slot:</span> <span className="font-semibold">{order.delivery_date} · {order.slot_start}–{order.slot_end}</span></p>
                <p><span className="text-muted-foreground">Paid:</span> <span className="font-bold">₹{order.amount}</span></p>
              </div>
            )}
          </>
        )}
        {status === "failure" && (
          <>
            <XCircle data-testid="payment-failure-icon" className="mx-auto h-14 w-14 text-destructive" />
            <h1 className="mt-5 font-display text-3xl font-bold">Payment failed</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              No money was captured. Your cart is saved — you can try paying again.
            </p>
          </>
        )}
        {status === "pending" && (
          <>
            <Clock className="mx-auto h-14 w-14 text-accent" />
            <h1 className="mt-5 font-display text-3xl font-bold">Payment pending</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              We're still waiting for PayU's confirmation. If money was debited, it will reflect shortly.
            </p>
          </>
        )}
        {status === "missing" && (
          <>
            <XCircle className="mx-auto h-14 w-14 text-destructive" />
            <h1 className="mt-5 font-display text-3xl font-bold">Order not found</h1>
          </>
        )}
        <div className="mt-8 flex justify-center gap-3">
          {status === "success" && order && (
            <Link to={`/track?order_id=${order.id}&phone=${order.customer.phone}`}>
              <Button data-testid="track-order-button" className="rounded-full px-8">
                Track order
              </Button>
            </Link>
          )}
          <Link to="/">
            <Button data-testid="back-to-menu-button" variant="secondary" className="rounded-full px-8">
              Back to menu
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
