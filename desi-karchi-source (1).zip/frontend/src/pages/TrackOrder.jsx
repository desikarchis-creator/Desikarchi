import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { ArrowLeft, Bike, CheckCircle2, ChefHat, Package, SearchX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trackOrder } from "@/api";

const STEPS = [
  { key: "order_received", label: "Order received", icon: Package },
  { key: "prepared", label: "Prepared", icon: ChefHat },
  { key: "out_for_delivery", label: "Out for delivery", icon: Bike },
  { key: "delivered", label: "Delivered", icon: CheckCircle2 },
];

export default function TrackOrder() {
  const [params] = useSearchParams();
  const [orderId, setOrderId] = useState(params.get("order_id") || "");
  const [phone, setPhone] = useState(params.get("phone") || "");
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const search = async () => {
    if (!orderId.trim() || !/^\d{10}$/.test(phone.trim())) {
      setError("Enter your order ID and 10-digit phone number");
      return;
    }
    setBusy(true);
    setError("");
    setOrder(null);
    try {
      setOrder(await trackOrder(orderId.trim(), phone.trim()));
    } catch (err) {
      setError(err?.response?.data?.detail || "Order not found - check order ID and phone number");
    } finally {
      setBusy(false);
    }
  };

  const stepIndex = order ? STEPS.findIndex((s) => s.key === order.status) : -1;

  return (
    <div data-testid="track-page" className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <img src="/logo.png" alt="Desi Karchi logo" className="h-10 w-10 rounded-full border-2 border-accent/60 object-cover" />
            <p className="font-display text-xl font-bold">Track your order</p>
          </div>
          <Link to="/">
            <Button data-testid="track-back-button" variant="secondary" className="rounded-full">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to site
            </Button>
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-5 py-12">
        <div className="rounded-3xl border border-border bg-card p-7 shadow-sm animate-fade-up">
          <p className="text-sm text-muted-foreground">
            Enter your order ID (from the confirmation page or email) and the phone number you ordered with.
          </p>
          <div className="mt-4 space-y-3">
            <Input
              data-testid="track-order-id-input"
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="Order ID"
              className="bg-background"
            />
            <Input
              data-testid="track-phone-input"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              onKeyDown={(e) => e.key === "Enter" && search()}
              placeholder="Phone number"
              inputMode="numeric"
              className="bg-background"
            />
            <Button data-testid="track-submit-button" className="w-full rounded-full" size="lg" onClick={search} disabled={busy}>
              {busy ? "Checking…" : "Track order"}
            </Button>
          </div>
          {error && (
            <p data-testid="track-error" className="mt-4 flex items-center gap-1.5 text-sm font-semibold text-destructive">
              <SearchX className="h-4 w-4" /> {error}
            </p>
          )}
        </div>

        {order && (
          <div data-testid="track-result" className="mt-6 rounded-3xl border border-border bg-card p-7 shadow-sm animate-fade-up">
            <div className="flex items-center justify-between">
              <p className="font-mono text-sm font-bold text-muted-foreground">#{order.id.slice(0, 8).toUpperCase()}</p>
              <p data-testid="track-amount" className="text-lg font-bold">₹{order.amount}</p>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Hi {order.customer_name},</p>

            {order.payment_status === "success" ? (
              <div className="mt-7 flex items-start">
                {STEPS.map((s, i) => {
                  const Icon = s.icon;
                  const done = i <= stepIndex;
                  return (
                    <div key={s.key} className="flex flex-1 items-start">
                      <div data-testid={`track-step-${s.key}`} className="flex flex-col items-center gap-2">
                        <span
                          className={`flex h-11 w-11 items-center justify-center rounded-full border-2 transition-colors ${
                            done ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-muted-foreground"
                          }`}
                        >
                          <Icon className="h-5 w-5" />
                        </span>
                        <p className={`text-center text-xs font-semibold ${done ? "text-foreground" : "text-muted-foreground"}`}>
                          {s.label}
                        </p>
                      </div>
                      {i < STEPS.length - 1 && (
                        <div className={`mx-1 mt-5 h-0.5 flex-1 ${i < stepIndex ? "bg-primary" : "bg-border"}`} />
                      )}
                    </div>
                  );
                })}
              </div>
            ) : order.payment_status === "pending" ? (
              <p data-testid="track-payment-pending" className="mt-6 rounded-xl bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">
                Payment pending — your order will be confirmed once payment completes.
              </p>
            ) : (
              <p data-testid="track-payment-failed" className="mt-6 rounded-xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
                Payment failed — this order was not confirmed. Please place a new order.
              </p>
            )}

            <div className="mt-7 space-y-1.5 border-t border-dashed border-border pt-5 text-sm">
              <p>
                <span className="text-muted-foreground">Items:</span>{" "}
                {order.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}
              </p>
              <p>
                <span className="text-muted-foreground">Delivery slot:</span>{" "}
                <span data-testid="track-slot" className="font-semibold">
                  {order.delivery_date} · {order.slot_start}–{order.slot_end}
                </span>
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
