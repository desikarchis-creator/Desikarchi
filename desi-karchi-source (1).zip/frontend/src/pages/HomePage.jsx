import { useCallback, useEffect, useState } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { MenuSection } from "@/components/MenuSection";
import { CartDrawer } from "@/components/CartDrawer";
import { CheckoutModal } from "@/components/CheckoutModal";
import { getConfig, getContent, getMenu } from "@/api";
import { CONTENT_DEFAULTS } from "@/contentDefaults";
import { useCart } from "@/context/CartContext";

export default function HomePage() {
  const [menu, setMenu] = useState([]);
  const [config, setConfig] = useState(null);
  const [content, setContent] = useState(CONTENT_DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const { items } = useCart();

  const loadMenu = useCallback(() => {
    getMenu().then(setMenu).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    loadMenu();
    getConfig().then(setConfig).catch(() => {});
    getContent()
      .then((d) => setContent((prev) => ({ ...prev, ...d })))
      .catch(() => {});
  }, [loadMenu]);

  return (
    <div id="top" data-testid="home-page" className="min-h-screen">
      <Header onCartOpen={() => setCartOpen(true)} content={content} />
      <Hero content={content} pincodes={config?.pincodes} />
      <MenuSection menu={menu} loading={loading} content={content} />

      <section data-testid="how-it-works" className="border-t border-border bg-card/60">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-3">
          {[
            { n: "01", t: content.step1_title, d: content.step1_desc },
            { n: "02", t: content.step2_title, d: content.step2_desc },
            { n: "03", t: content.step3_title, d: content.step3_desc },
          ].map((s, i) => (
            <div key={s.n} className="animate-fade-up" style={{ animationDelay: `${i * 120}ms` }}>
              <p className="font-display text-4xl font-bold text-primary/30">{s.n}</p>
              <p className="mt-2 font-display text-xl font-semibold">{s.t}</p>
              <p className="mt-1.5 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer data-testid="site-footer" className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground">
          <p className="font-display text-lg font-bold text-foreground">Desi Karchi</p>
          <p>{content.footer_text}</p>
        </div>
      </footer>

      <CartDrawer
        open={cartOpen}
        onOpenChange={setCartOpen}
        pincodes={config?.pincodes}
        deliveryCharge={config?.delivery_charge ?? 0}
        onCheckout={() => {
          if (items.length === 0) return;
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
      />
      <CheckoutModal open={checkoutOpen} onOpenChange={setCheckoutOpen} config={config} />
    </div>
  );
}
