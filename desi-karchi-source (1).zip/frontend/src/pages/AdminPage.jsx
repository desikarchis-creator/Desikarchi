import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ClipboardList, FileText, ImagePlus, KeyRound, Lock, MapPin, Pencil, Plus, Trash2, UtensilsCrossed, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addDish, adminLogin, changePassword, deleteDish, getConfig, getContent, getMenu, getOrders, resetPassword, updateContent, updateDeliveryCharge, updateDish, updateOrderStatus, updatePincodes, uploadImage } from "@/api";
import { CONTENT_FIELDS } from "@/contentDefaults";

const EMPTY = { name: "", description: "", price: "", category: "", image: "", veg: true, spice: 1 };

const STATUS_STYLES = {
  order_received: "bg-blue-100 text-blue-800",
  prepared: "bg-amber-100 text-amber-800",
  out_for_delivery: "bg-orange-100 text-orange-800",
  confirmed: "bg-green-100 text-green-800",
  delivered: "bg-green-100 text-green-800",
  payment_pending: "bg-amber-100 text-amber-800",
  payment_failed: "bg-red-100 text-red-800",
};

const StatusBadge = ({ status }) => (
  <span data-testid="order-status-badge" className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${STATUS_STYLES[status] || "bg-secondary text-secondary-foreground"}`}>
    {String(status || "").replace(/_/g, " ")}
  </span>
);

export default function AdminPage() {
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [authed, setAuthed] = useState(false);
  const [dishes, setDishes] = useState([]);
  const [dish, setDish] = useState(EMPTY);
  const [busy, setBusy] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [resetCode, setResetCode] = useState("");
  const [resetNewPin, setResetNewPin] = useState("");
  const [curPin, setCurPin] = useState("");
  const [nextPin, setNextPin] = useState("");
  const [orders, setOrders] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [contentForm, setContentForm] = useState(null);
  const [savingContent, setSavingContent] = useState(false);
  const [pincodesForm, setPincodesForm] = useState([]);
  const [newPincode, setNewPincode] = useState("");
  const [savingPincodes, setSavingPincodes] = useState(false);
  const [deliveryCharge, setDeliveryCharge] = useState("0");
  const [savingCharge, setSavingCharge] = useState(false);

  useEffect(() => {
    if (authed) {
      getMenu().then(setDishes).catch(() => {});
      getOrders(pin).then(setOrders).catch(() => {});
      getContent().then(setContentForm).catch(() => {});
      getConfig()
        .then((c) => {
          setPincodesForm(c.pincodes || []);
          setDeliveryCharge(String(c.delivery_charge ?? 0));
        })
        .catch(() => {});
    }
  }, [authed]);

  const login = async () => {
    try {
      await adminLogin(username, pin);
      setAuthed(true);
    } catch {
      toast.error("Invalid username or password");
    }
  };

  const set = (k) => (e) => setDish((d) => ({ ...d, [k]: e.target.value }));

  const submit = async () => {
    if (!dish.name.trim() || !dish.price || Number(dish.price) <= 0) {
      toast.error("Dish name and a valid price are required");
      return;
    }
    setBusy(true);
    try {
      const payload = {
        ...dish,
        name: dish.name.trim(),
        price: Number(dish.price),
        category: dish.category.trim() || "Mains",
        image: dish.image.trim() || null,
      };
      if (editingId) {
        const updated = await updateDish(pin, editingId, payload);
        setDishes((prev) => prev.map((d) => (d.id === editingId ? updated : d)));
        toast.success(`"${updated.name}" updated`);
        setEditingId(null);
      } else {
        const created = await addDish(pin, payload);
        setDishes((prev) => [...prev, created]);
        toast.success(`"${created.name}" added to the menu`);
      }
      setDish(EMPTY);
    } catch (err) {
      if (err?.response?.status === 401) setAuthed(false);
      toast.error(err?.response?.data?.detail || "Could not save dish");
    } finally {
      setBusy(false);
    }
  };

  const startEdit = (d) => {
    setEditingId(d.id);
    setDish({
      name: d.name,
      description: d.description || "",
      price: String(d.price),
      category: d.category || "",
      image: d.image || "",
      veg: d.veg,
      spice: d.spice,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setDish(EMPTY);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { url } = await uploadImage(pin, file);
      setDish((d) => ({ ...d, image: url }));
      toast.success("Image uploaded");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Image upload failed");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };

  const remove = async (id, name) => {
    try {
      await deleteDish(pin, id);
      setDishes((prev) => prev.filter((d) => d.id !== id));
      toast.success(`"${name}" removed`);
    } catch {
      toast.error("Could not remove dish");
    }
  };

  const resetPinHandler = async () => {
    try {
      await resetPassword({ recovery_code: resetCode.trim(), new_password: resetNewPin.trim() });
      toast.success("Password reset! Log in with your new password.");
      setShowReset(false);
      setResetCode("");
      setResetNewPin("");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not reset password");
    }
  };

  const changePinHandler = async () => {
    try {
      await changePassword({ current_password: curPin, new_password: nextPin });
      setPin(nextPin);
      setCurPin("");
      setNextPin("");
      toast.success("Password updated successfully");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not change password");
    }
  };

  const saveContent = async () => {
    setSavingContent(true);
    try {
      await updateContent(pin, contentForm);
      toast.success("Site text updated — live on the site now");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not save site text");
    } finally {
      setSavingContent(false);
    }
  };

  const addPincode = () => {
    if (!/^\d{6}$/.test(newPincode)) return toast.error("Enter a valid 6-digit pincode");
    if (pincodesForm.includes(newPincode)) return toast.error("Pincode already in the list");
    setPincodesForm((p) => [...p, newPincode]);
    setNewPincode("");
  };

  const removePincode = (p) => setPincodesForm((prev) => prev.filter((x) => x !== p));

  const savePincodes = async () => {
    setSavingPincodes(true);
    try {
      const res = await updatePincodes(pin, pincodesForm);
      setPincodesForm(res.pincodes);
      toast.success("Delivery pincodes updated — live now");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not save pincodes");
    } finally {
      setSavingPincodes(false);
    }
  };

  const setOrderStatus = async (orderId, status) => {
    try {
      await updateOrderStatus(pin, orderId, status);
      setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
      toast.success(`Order #${orderId.slice(0, 8).toUpperCase()} marked ${status.replace(/_/g, " ")}`);
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not update status");
    }
  };

  const saveDeliveryCharge = async () => {
    const value = Number(deliveryCharge);
    if (!Number.isFinite(value) || value < 0 || value > 500) {
      return toast.error("Enter a charge between 0 and 500");
    }
    setSavingCharge(true);
    try {
      const res = await updateDeliveryCharge(pin, value);
      setDeliveryCharge(String(res.delivery_charge));
      toast.success(value === 0 ? "Delivery is now FREE" : `Delivery charge set to ₹${value}`);
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not save delivery charge");
    } finally {
      setSavingCharge(false);
    }
  };

  return (
    <div data-testid="admin-page" className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <img src="/logo.png" alt="Desi Karchi logo" className="h-10 w-10 rounded-full border-2 border-accent/60 object-cover" />
            <p className="font-display text-xl font-bold">Desi Karchi · Owner Panel</p>
          </div>
          <Link to="/">
            <Button data-testid="admin-back-button" variant="secondary" className="rounded-full">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to site
            </Button>
          </Link>
        </div>
      </header>

      {!authed ? (
        <div className="mx-auto flex max-w-sm flex-col items-center px-5 pt-24 animate-fade-up">
          <div className="w-full rounded-3xl border border-border bg-card p-8 text-center shadow-sm">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Lock className="h-6 w-6 text-primary" />
            </span>
            <h1 className="mt-4 font-display text-2xl font-bold">Owner Login</h1>
            <p className="mt-1 text-sm text-muted-foreground">Enter your owner username &amp; password.</p>
            <Input
              data-testid="admin-username-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              autoComplete="username"
              className="mt-5 bg-background"
            />
            <Input
              data-testid="admin-pin-input"
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && login()}
              placeholder="Password"
              autoComplete="current-password"
              className="mt-2.5 bg-background"
            />
            <Button data-testid="admin-login-button" className="mt-3 w-full rounded-full" size="lg" onClick={login}>
              Unlock panel
            </Button>
            <button
              data-testid="admin-forgot-pin-link"
              onClick={() => setShowReset((s) => !s)}
              className="mt-3 text-xs font-semibold text-muted-foreground underline-offset-2 transition-colors hover:text-primary hover:underline"
            >
              Forgot password?
            </button>
            {showReset && (
              <div data-testid="admin-reset-form" className="mt-4 space-y-2.5 rounded-2xl border border-dashed border-border bg-background p-4 text-left">
                <p className="text-xs font-semibold text-muted-foreground">
                  Enter your recovery code and choose a new password (4–30 characters).
                </p>
                <Input
                  data-testid="admin-recovery-code-input"
                  value={resetCode}
                  onChange={(e) => setResetCode(e.target.value)}
                  placeholder="Recovery code"
                  className="bg-card"
                />
                <Input
                  data-testid="admin-reset-new-pin-input"
                  type="password"
                  value={resetNewPin}
                  onChange={(e) => setResetNewPin(e.target.value)}
                  placeholder="New password"
                  autoComplete="new-password"
                  className="bg-card"
                />
                <Button data-testid="admin-reset-pin-button" variant="secondary" className="w-full rounded-full" onClick={resetPinHandler}>
                  Reset password
                </Button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <main className="mx-auto max-w-5xl space-y-8 px-5 py-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          <section data-testid="admin-add-form" className="h-fit rounded-3xl border border-border bg-card p-6 shadow-sm">
            <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
              {editingId ? <Pencil className="h-5 w-5 text-primary" /> : <Plus className="h-5 w-5 text-primary" />}
              {editingId ? "Edit dish" : "Add a dish"}
            </h2>
            <div className="mt-5 space-y-3">
              <Input data-testid="admin-dish-name" value={dish.name} onChange={set("name")} placeholder="Dish name *" className="bg-background" />
              <Textarea data-testid="admin-dish-description" value={dish.description} onChange={set("description")} placeholder="Short description" rows={2} className="bg-background" />
              <div className="grid grid-cols-2 gap-3">
                <Input data-testid="admin-dish-price" type="number" min="1" value={dish.price} onChange={set("price")} placeholder="Price ₹ *" className="bg-background" />
                <Input data-testid="admin-dish-category" value={dish.category} onChange={set("category")} placeholder="Category (e.g. Mains)" className="bg-background" />
              </div>
              <div className="rounded-xl border border-border bg-background p-3">
                <div className="flex items-center gap-3">
                  <label
                    data-testid="admin-dish-image-upload"
                    className="flex cursor-pointer items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold transition-colors hover:bg-secondary"
                  >
                    <ImagePlus className="h-4 w-4 text-primary" />
                    {uploading ? "Uploading…" : "Upload image"}
                    <input
                      data-testid="admin-dish-image-file-input"
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={uploading}
                    />
                  </label>
                  {dish.image && (
                    <img
                      src={dish.image}
                      alt="Dish preview"
                      data-testid="admin-dish-image-preview"
                      className="h-12 w-12 rounded-lg border border-border object-cover"
                    />
                  )}
                </div>
                <Input
                  data-testid="admin-dish-image"
                  value={dish.image}
                  onChange={set("image")}
                  placeholder="…or paste an image URL"
                  className="mt-2.5 bg-card"
                />
              </div>
              <div className="flex items-center justify-between rounded-xl border border-border bg-background px-4 py-2.5">
                <span className="text-sm font-semibold">Vegetarian</span>
                <Switch data-testid="admin-dish-veg" checked={dish.veg} onCheckedChange={(v) => setDish((d) => ({ ...d, veg: v }))} />
              </div>
              <div className="flex items-center justify-between rounded-xl border border-border bg-background px-4 py-2.5">
                <span className="text-sm font-semibold">Spice level</span>
                <Select value={String(dish.spice)} onValueChange={(v) => setDish((d) => ({ ...d, spice: Number(v) }))}>
                  <SelectTrigger data-testid="admin-dish-spice" className="w-28 bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">None</SelectItem>
                    <SelectItem value="1">Mild</SelectItem>
                    <SelectItem value="2">Medium</SelectItem>
                    <SelectItem value="3">Hot</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button data-testid="admin-add-dish-button" className="w-full rounded-full" size="lg" onClick={submit} disabled={busy}>
                {editingId ? <Pencil className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                {busy ? "Saving…" : editingId ? "Save changes" : "Add dish"}
              </Button>
              {editingId && (
                <button
                  data-testid="admin-cancel-edit-button"
                  onClick={cancelEdit}
                  className="flex w-full items-center justify-center gap-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:text-destructive"
                >
                  <X className="h-3.5 w-3.5" /> Cancel editing
                </button>
              )}
            </div>

            <div data-testid="admin-change-pin-card" className="mt-6 space-y-2.5 rounded-2xl border border-dashed border-border bg-background p-4">
              <p className="flex items-center gap-1.5 text-sm font-semibold">
                <KeyRound className="h-4 w-4 text-primary" /> Change password
              </p>
              <div className="grid grid-cols-2 gap-2.5">
                <Input
                  data-testid="admin-current-pin-input"
                  type="password"
                  value={curPin}
                  onChange={(e) => setCurPin(e.target.value)}
                  placeholder="Current password"
                  autoComplete="current-password"
                  className="bg-card"
                />
                <Input
                  data-testid="admin-new-pin-input"
                  type="password"
                  value={nextPin}
                  onChange={(e) => setNextPin(e.target.value)}
                  placeholder="New password"
                  autoComplete="new-password"
                  className="bg-card"
                />
              </div>
              <Button data-testid="admin-change-pin-button" variant="secondary" className="w-full rounded-full" onClick={changePinHandler}>
                Update password
              </Button>
            </div>
          </section>

          <section data-testid="admin-menu-list" className="rounded-3xl border border-border bg-card p-6 shadow-sm">
            <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
              <UtensilsCrossed className="h-5 w-5 text-primary" /> Current menu
              <span data-testid="admin-dish-count" className="rounded-full bg-primary/10 px-3 py-0.5 text-sm font-bold text-primary">{dishes.length}</span>
            </h2>
            <div className="mt-5 space-y-2.5">
              {dishes.length === 0 && (
                <p data-testid="admin-empty-menu" className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                  No dishes yet — add your first one.
                </p>
              )}
              {dishes.map((d) => (
                <div key={d.id} data-testid={`admin-dish-row-${d.id}`} className="flex items-center gap-3 rounded-xl border border-border bg-background p-3">
                  {d.image ? (
                    <img src={d.image} alt={d.name} className="h-12 w-12 rounded-lg object-cover" />
                  ) : (
                    <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary font-display text-xl text-primary/50">
                      {d.name.charAt(0)}
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1.5 truncate text-sm font-semibold">
                      <span className={`inline-block h-2.5 w-2.5 rounded-full ${d.veg ? "bg-green-700" : "bg-red-700"}`} />
                      {d.name}
                    </p>
                    <p className="text-xs text-muted-foreground">₹{d.price} · {d.category}</p>
                  </div>
                  <button
                    data-testid={`admin-dish-edit-${d.id}`}
                    onClick={() => startEdit(d)}
                    className="rounded-full p-2.5 text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    data-testid={`admin-dish-delete-${d.id}`}
                    onClick={() => remove(d.id, d.name)}
                    className="rounded-full p-2.5 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </section>
        </div>

        <section data-testid="admin-orders-section" className="rounded-3xl border border-border bg-card p-6 shadow-sm">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
            <ClipboardList className="h-5 w-5 text-primary" /> Orders
            <span data-testid="admin-order-count" className="rounded-full bg-primary/10 px-3 py-0.5 text-sm font-bold text-primary">{orders.length}</span>
          </h2>
          <div className="mt-5 space-y-3">
            {orders.length === 0 && (
              <p data-testid="admin-empty-orders" className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                No orders yet — they'll appear here as soon as customers order.
              </p>
            )}
            {orders.map((o) => (
              <div key={o.id} data-testid={`admin-order-${o.id}`} className="rounded-xl border border-border bg-background p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-muted-foreground">#{o.id.slice(0, 8).toUpperCase()}</span>
                    <StatusBadge status={o.status} />
                    {o.payment_status === "success" && (
                      <Select value={o.status} onValueChange={(v) => setOrderStatus(o.id, v)}>
                        <SelectTrigger
                          data-testid={`order-status-select-${o.id}`}
                          className="h-8 w-44 bg-card text-xs font-semibold"
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="order_received">Order received</SelectItem>
                          <SelectItem value="prepared">Prepared</SelectItem>
                          <SelectItem value="out_for_delivery">Out for delivery</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                  <span data-testid={`admin-order-amount-${o.id}`} className="text-base font-bold">₹{o.amount}</span>
                </div>
                <div className="mt-3 grid gap-3 text-sm sm:grid-cols-3">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Customer</p>
                    <p className="mt-0.5 font-semibold">{o.customer.name} · {o.customer.phone}</p>
                    <p className="text-xs text-muted-foreground">{o.customer.address}, {o.customer.pincode}</p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Items</p>
                    <p className="mt-0.5">{o.items.map((i) => `${i.qty}× ${i.name}`).join(", ")}</p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Delivery slot</p>
                    <p className="mt-0.5 font-semibold">{o.delivery_date} · {o.slot_start}–{o.slot_end}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section data-testid="admin-pincodes-section" className="rounded-3xl border border-border bg-card p-6 shadow-sm">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
            <MapPin className="h-5 w-5 text-primary" /> Delivery pincodes
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Customers can order only to these pincodes. Changes apply instantly across the site.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {pincodesForm.map((p) => (
              <span
                key={p}
                data-testid={`pincode-chip-${p}`}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-4 py-1.5 text-sm font-semibold"
              >
                {p}
                <button
                  data-testid={`pincode-remove-${p}`}
                  onClick={() => removePincode(p)}
                  className="text-muted-foreground transition-colors hover:text-destructive"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </span>
            ))}
          </div>
          <div className="mt-4 flex max-w-sm gap-2">
            <Input
              data-testid="admin-new-pincode-input"
              value={newPincode}
              onChange={(e) => setNewPincode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              onKeyDown={(e) => e.key === "Enter" && addPincode()}
              placeholder="Add pincode, e.g. 110017"
              inputMode="numeric"
              className="bg-background"
            />
            <Button data-testid="admin-add-pincode-button" variant="secondary" className="rounded-full" onClick={addPincode}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <Button
            data-testid="admin-save-pincodes-button"
            className="mt-4 rounded-full px-8"
            onClick={savePincodes}
            disabled={savingPincodes || pincodesForm.length === 0}
          >
            {savingPincodes ? "Saving…" : "Save pincodes"}
          </Button>

          <div className="mt-6 border-t border-dashed border-border pt-5">
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Delivery charge (₹ — 0 means free delivery)
            </label>
            <div className="mt-2 flex max-w-sm gap-2">
              <Input
                data-testid="admin-delivery-charge-input"
                type="number"
                min="0"
                max="500"
                value={deliveryCharge}
                onChange={(e) => setDeliveryCharge(e.target.value)}
                className="bg-background"
              />
              <Button
                data-testid="admin-save-charge-button"
                className="rounded-full"
                onClick={saveDeliveryCharge}
                disabled={savingCharge}
              >
                {savingCharge ? "Saving…" : "Save charge"}
              </Button>
            </div>
          </div>
        </section>

        <section data-testid="admin-content-section" className="rounded-3xl border border-border bg-card p-6 shadow-sm">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold">
            <FileText className="h-5 w-5 text-primary" /> Site text
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Edit any text shown on the customer site. Changes go live instantly.
          </p>
          {contentForm && (
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {CONTENT_FIELDS.map((f) => (
                <div key={f.key} className={f.textarea ? "sm:col-span-2" : ""}>
                  <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {f.label}
                  </label>
                  {f.textarea ? (
                    <Textarea
                      data-testid={`content-field-${f.key}`}
                      rows={2}
                      value={contentForm[f.key] || ""}
                      onChange={(e) => setContentForm((p) => ({ ...p, [f.key]: e.target.value }))}
                      className="mt-1 bg-background"
                    />
                  ) : (
                    <Input
                      data-testid={`content-field-${f.key}`}
                      value={contentForm[f.key] || ""}
                      onChange={(e) => setContentForm((p) => ({ ...p, [f.key]: e.target.value }))}
                      className="mt-1 bg-background"
                    />
                  )}
                </div>
              ))}
            </div>
          )}
          <Button
            data-testid="admin-save-content-button"
            className="mt-5 rounded-full px-8"
            onClick={saveContent}
            disabled={savingContent || !contentForm}
          >
            {savingContent ? "Saving…" : "Save site text"}
          </Button>
        </section>
      </main>
      )}
    </div>
  );
}
