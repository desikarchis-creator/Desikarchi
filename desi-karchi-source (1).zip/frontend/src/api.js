import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export const getConfig = () => axios.get(`${API}/config`).then((r) => r.data);
export const getContent = () => axios.get(`${API}/content`).then((r) => r.data);
export const updateContent = (pin, updates) =>
  axios.put(`${API}/content`, { updates }, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const updatePincodes = (pin, pincodes) =>
  axios.put(`${API}/admin/pincodes`, { pincodes }, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const updateOrderStatus = (pin, orderId, status) =>
  axios.put(`${API}/admin/orders/${orderId}/status`, { status }, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const updateDeliveryCharge = (pin, charge) =>
  axios.put(`${API}/admin/delivery-charge`, { charge }, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const trackOrder = (orderId, phone) =>
  axios.get(`${API}/orders/${orderId}/track`, { params: { phone } }).then((r) => r.data);
export const getMenu = () => axios.get(`${API}/menu`).then((r) => r.data);
export const addDish = (pin, dish) =>
  axios.post(`${API}/menu`, dish, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const deleteDish = (pin, dishId) =>
  axios.delete(`${API}/menu/${dishId}`, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const updateDish = (pin, dishId, dish) =>
  axios.put(`${API}/menu/${dishId}`, dish, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const getOrders = (pin) =>
  axios.get(`${API}/admin/orders`, { headers: { "x-admin-pin": pin } }).then((r) => r.data);
export const uploadImage = (pin, file) => {
  const form = new FormData();
  form.append("file", file);
  return axios
    .post(`${API}/upload`, form, { headers: { "x-admin-pin": pin } })
    .then((r) => r.data);
};
export const adminLogin = (username, password) =>
  axios.post(`${API}/admin/login`, { username, password }).then((r) => r.data);
export const changePassword = (data) => axios.post(`${API}/admin/change-password`, data).then((r) => r.data);
export const resetPassword = (data) => axios.post(`${API}/admin/reset-password`, data).then((r) => r.data);
export const createOrder = (order) => axios.post(`${API}/orders`, order).then((r) => r.data);
export const startPayu = (orderId) =>
  axios.post(`${API}/payments/payu/start`, { order_id: orderId }).then((r) => r.data);
export const getPaymentStatus = (orderId) =>
  axios.get(`${API}/orders/${orderId}/payment-status`).then((r) => r.data);
export const getOrder = (orderId) => axios.get(`${API}/orders/${orderId}`).then((r) => r.data);
