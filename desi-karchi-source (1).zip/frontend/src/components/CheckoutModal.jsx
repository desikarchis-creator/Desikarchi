import { useMemo, useState } from "react";
import { CalendarClock, CreditCard, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/context/CartContext";
import { createOrder, startPayu } from "@/api";
import { dateLabel, dateValue, nextDates, slotLabel, slotsForDate } from "@/utils/slots";

const postToPayu = (checkoutUrl, fields) => {
  const form = document.createElement("form");
  form.method = "POST";
  form.action = checkoutUrl;
  Object.entries(fields).forEach(([name, value]) => {
    const input = document.createElement("input");
    input.type = "hidden";
    input.name = name;
    input.value = value ?? "";
    form.appendChild(input);
  });
  document.body.appendChild(form);
  form.submit();
};

export const CheckoutModal = ({ open, onOpenChange, config }) => {
  const { items, subtotal } = useCart();
  const pincodes = config?.pincodes || ["110019"];
  const deliveryCharge = config?.delivery_charge ?? 0;
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", pincode: "" });
  const [date, setDate] = useState(null);
  const [slot, setSlot] = useState(null);
  const [busy, setBusy] = useState(false);

  const dates = useMemo(() => nextDates(7), []);
  const slots = useMemo(
    () => (date && config ? slotsForDate(dateValue(date), config.slots, config.min_hours) : []),
    [date, config]
  );

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const valid =
    form.name.trim().length >= 2 &&
    /^[6-9]\d{9}$/.test(form.phone) &&
    /^\S+@\S+\.\S+$/.test(form.email.trim()) &&
    form.address.trim().length >= 10 &&
    pincodes.includes(form.pincode) &&
    date &&
    slot;

  const submit = async () => {
    if (!valid || busy) return;
    setBusy(true);
    try {
      const order = await createOrder({
        items: items.map((i) => ({ dish_id: i.dish.id, qty: i.qty })),
        customer: {
          name: form.name.trim(),
          phone: form.phone,
          email: form.email.trim(),
          address: form.address.trim(),
          pincode: form.pincode,
        },
        delivery_date: dateValue(date),
        slot_start: slot.start,
        slot_end: slot.end,
      });
      try {
        const { checkout_url, fields } = await startPayu(order.id);
        postToPayu(checkout_url, fields);
      } catch (err) {
        if (err?.response?.status === 503) {
          toast.error("Online payment is not configured yet. The owner needs to add PayU keys — your order is saved, please try paying shortly.");
        } else {
          toast.error(err?.response?.data?.detail || "Could not start payment. Please try again.");
        }
        setBusy(false);
      }
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Could not place the order. Please try again.");
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        data-testid="checkout-modal"
        className="max-h-[92vh] overflow-y-auto bg-background sm:max-w-lg"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Checkout</DialogTitle>
          <DialogDescription>Delivery details, slot at least 24 hours ahead, and secure PayU payment.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Name</label>
              <Input data-testid="checkout-name-input" value={form.name} onChange={set("name")} placeholder="Your full name" className="mt-1 bg-card" />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Phone</label>
              <Input data-testid="checkout-phone-input" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value.replace(/\D/g, "").slice(0, 10) }))} placeholder="10-digit mobile" inputMode="numeric" className="mt-1 bg-card" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Email (for order confirmation)</label>
            <Input data-testid="checkout-email-input" type="email" value={form.email} onChange={set("email")} placeholder="you@example.com" className="mt-1 bg-card" />
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Full address</label>
            <Textarea data-testid="checkout-address-input" value={form.address} onChange={set("address")} placeholder="House no, street, landmark — Kalkaji" rows={2} className="mt-1 bg-card" />
          </div>
          <div className="max-w-40">
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Pincode</label>
            <Input data-testid="checkout-pincode-input" value={form.pincode} onChange={(e) => setForm((f) => ({ ...f, pincode: e.target.value.replace(/\D/g, "").slice(0, 6) }))} placeholder="110019" inputMode="numeric" className="mt-1 bg-card" />
            {form.pincode.length === 6 && !pincodes.includes(form.pincode) && (
              <p data-testid="checkout-pincode-error" className="mt-1.5 text-xs font-semibold text-destructive">
                We deliver only in: {pincodes.join(", ")}
              </p>
            )}
          </div>

          <div>
            <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <CalendarClock className="h-3.5 w-3.5" /> Delivery slot (min 24 hrs ahead)
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {dates.map((d) => {
                const hasSlots = config && slotsForDate(dateValue(d), config.slots, config.min_hours).length > 0;
                return (
                  <button
                    key={dateValue(d)}
                    data-testid={`slot-date-${dateValue(d)}`}
                    disabled={!hasSlots}
                    onClick={() => { setDate(d); setSlot(null); }}
                    className={`rounded-full px-4 py-2 text-xs font-semibold transition-colors ${
                      date && dateValue(date) === dateValue(d)
                        ? "bg-primary text-primary-foreground"
                        : hasSlots
                          ? "border border-border bg-card hover:bg-secondary"
                          : "cursor-not-allowed border border-border/50 text-muted-foreground/40"
                    }`}
                  >
                    {dateLabel(d)}
                  </button>
                );
              })}
            </div>
            {date && (
              <div className="mt-2 flex flex-wrap gap-2">
                {slots.map((s) => (
                  <button
                    key={s.start}
                    data-testid={`slot-time-${s.start.replace(":", "")}`}
                    onClick={() => setSlot(s)}
                    className={`rounded-full px-4 py-2 text-xs font-semibold transition-colors ${
                      slot?.start === s.start
                        ? "bg-accent text-accent-foreground"
                        : "border border-border bg-card hover:bg-secondary"
                    }`}
                  >
                    {slotLabel(s)}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                {items.reduce((s, i) => s + i.qty, 0)} items · {deliveryCharge > 0 ? `delivery ₹${deliveryCharge}` : "free delivery"}
              </span>
              <span data-testid="checkout-total" className="text-base font-bold">₹{subtotal + deliveryCharge}</span>
            </div>
          </div>

          <Button
            data-testid="checkout-pay-button"
            size="lg"
            className="w-full rounded-full"
            disabled={!valid || busy}
            onClick={submit}
          >
            {busy ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <CreditCard className="mr-2 h-4 w-4" />
            )}
            {busy ? "Opening PayU…" : `Pay ₹${subtotal + deliveryCharge} with PayU`}
          </Button>
          <p className="text-center text-[11px] text-muted-foreground">
            Secure payment via PayU · Cards, UPI, NetBanking
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};
