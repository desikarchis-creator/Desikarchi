import { useState } from "react";
import { ArrowDown, CheckCircle2, MapPin, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Hero = ({ content, pincodes = ["110019"] }) => {
  const [pin, setPin] = useState("");
  const [result, setResult] = useState(null);

  const check = () => {
    if (!/^\d{6}$/.test(pin)) return setResult("invalid");
    setResult(pincodes.includes(pin) ? "yes" : "no");
  };

  return (
    <section data-testid="hero-section" className="grain-overlay relative overflow-hidden">
      <div className="mx-auto max-w-6xl px-5 pb-16 pt-14 md:pb-24 md:pt-20">
        <div className="max-w-2xl animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-primary">
            <MapPin className="h-3.5 w-3.5" /> {content.hero_badge}
          </span>
          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            {content.hero_title_1}{" "}
            <span className="italic text-primary">{content.hero_title_highlight}</span>{" "}
            {content.hero_title_2}
          </h1>
          <p className="mt-5 max-w-xl text-base text-muted-foreground md:text-lg">
            {content.hero_subtitle}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button
              data-testid="hero-view-menu-button"
              size="lg"
              className="rounded-full px-7"
              onClick={() => document.getElementById("menu")?.scrollIntoView({ behavior: "smooth" })}
            >
              View the menu <ArrowDown className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="mt-10 max-w-md rounded-2xl border border-border bg-card/80 p-5 backdrop-blur">
            <p className="text-sm font-semibold">{content.pincode_widget_title}</p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {content.pincode_widget_text}
            </p>
            <div className="mt-3 flex gap-2">
              <Input
                data-testid="pincode-check-input"
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value.replace(/\D/g, "").slice(0, 6));
                  setResult(null);
                }}
                placeholder="Enter your pincode"
                inputMode="numeric"
                className="bg-background"
              />
              <Button data-testid="pincode-check-button" variant="secondary" onClick={check}>
                Check
              </Button>
            </div>
            {result === "yes" && (
              <p
                data-testid="pincode-check-success"
                className="mt-3 flex items-center gap-1.5 text-sm font-semibold text-green-700"
              >
                <CheckCircle2 className="h-4 w-4" /> Yes! We deliver to {pin}.
              </p>
            )}
            {result === "no" && (
              <p
                data-testid="pincode-check-failure"
                className="mt-3 flex items-center gap-1.5 text-sm font-semibold text-destructive"
              >
                <XCircle className="h-4 w-4" /> Sorry, we only deliver in {pincodes.join(", ")} for now.
              </p>
            )}
            {result === "invalid" && (
              <p
                data-testid="pincode-check-invalid"
                className="mt-3 text-sm font-semibold text-destructive"
              >
                Please enter a valid 6-digit pincode.
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
