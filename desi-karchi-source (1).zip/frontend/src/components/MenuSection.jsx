import { useMemo, useState } from "react";
import { Leaf } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { DishCard } from "@/components/DishCard";

export const MenuSection = ({ menu, loading, content }) => {
  const [category, setCategory] = useState("All");
  const [vegOnly, setVegOnly] = useState(false);

  const categories = useMemo(
    () => ["All", ...new Set(menu.map((d) => d.category).filter(Boolean))],
    [menu]
  );

  const dishes = useMemo(
    () =>
      menu.filter(
        (d) => (category === "All" || d.category === category) && (!vegOnly || d.veg)
      ),
    [menu, category, vegOnly]
  );

  return (
    <section id="menu" data-testid="menu-section" className="mx-auto max-w-6xl px-5 py-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            {content.menu_kicker}
          </p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">{content.menu_title}</h2>
        </div>
        <label
          data-testid="veg-only-toggle"
          className="flex cursor-pointer items-center gap-2.5 rounded-full border border-border bg-card px-4 py-2 text-sm font-semibold"
        >
          <Leaf className="h-4 w-4 text-green-700" />
          Veg only
          <Switch checked={vegOnly} onCheckedChange={setVegOnly} data-testid="veg-only-switch" />
        </label>
      </div>

      <div data-testid="menu-category-tabs" className="mt-7 flex flex-wrap gap-2">
        {categories.map((c) => (
          <button
            key={c}
            data-testid={`category-tab-${c.toLowerCase().replace(/\s+/g, "-")}`}
            onClick={() => setCategory(c)}
            className={`rounded-full px-5 py-2 text-sm font-semibold transition-colors duration-200 ${
              category === c
                ? "bg-primary text-primary-foreground"
                : "border border-border bg-card hover:bg-secondary"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {loading ? (
        <p data-testid="menu-loading" className="mt-14 text-center text-muted-foreground">
          Loading today's kadhai…
        </p>
      ) : dishes.length === 0 ? (
        <div
          data-testid="menu-empty-state"
          className="mt-10 rounded-2xl border border-dashed border-border bg-card/60 p-14 text-center"
        >
          <p className="font-display text-2xl font-semibold">The kadhai is being fired up</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Our owner is adding fresh dishes to the menu. Check back very soon!
          </p>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {dishes.map((d) => (
            <DishCard key={d.id} dish={d} />
          ))}
        </div>
      )}
    </section>
  );
};
