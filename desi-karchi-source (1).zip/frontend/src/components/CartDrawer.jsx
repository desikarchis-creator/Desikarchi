import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";

export const CartDrawer = ({ open, onOpenChange, onCheckout, pincodes = ["110019"], deliveryCharge = 0 }) => {
  const { items, setQty, clear, subtotal } = useCart();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent data-testid="cart-drawer" className="flex w-full flex-col bg-background sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 font-display text-2xl">
            <ShoppingBag className="h-5 w-5 text-primary" /> Your Order
          </SheetTitle>
          <SheetDescription>Review your dishes and proceed to checkout.</SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div data-testid="cart-empty-state" className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
            <ShoppingBag className="h-10 w-10 text-muted-foreground/40" />
            <p className="font-display text-xl font-semibold">Your cart is empty</p>
            <p className="max-w-60 text-sm text-muted-foreground">
              Add some desi goodness from the menu to get started.
            </p>
          </div>
        ) : (
          <>
            <div className="mt-4 flex-1 space-y-4 overflow-y-auto pr-1">
              {items.map(({ dish, qty }) => (
                <div
                  key={dish.id}
                  data-testid={`cart-item-${dish.id}`}
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-3"
                >
                  {dish.image && (
                    <img src={dish.image} alt={dish.name} className="h-14 w-14 rounded-lg object-cover" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{dish.name}</p>
                    <p className="text-xs text-muted-foreground">₹{dish.price} each</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      data-testid={`cart-item-minus-${dish.id}`}
                      onClick={() => setQty(dish.id, qty - 1)}
                      className="flex h-7 w-7 items-center justify-center rounded-full border border-border transition-colors hover:bg-secondary"
                    >
                      <Minus className="h-3 w-3" />
                    </button>
                    <span data-testid={`cart-item-qty-${dish.id}`} className="w-6 text-center text-sm font-bold">
                      {qty}
                    </span>
                    <button
                      data-testid={`cart-item-plus-${dish.id}`}
                      onClick={() => setQty(dish.id, qty + 1)}
                      className="flex h-7 w-7 items-center justify-center rounded-full border border-border transition-colors hover:bg-secondary"
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <span data-testid={`cart-item-total-${dish.id}`} className="w-14 text-right text-sm font-bold">
                    ₹{dish.price * qty}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-4 space-y-3 border-t border-border pt-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span data-testid="cart-subtotal" className="font-semibold">₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Delivery ({pincodes.join(", ")})</span>
                <span data-testid="cart-delivery-fee" className={`font-semibold ${deliveryCharge > 0 ? "" : "text-green-700"}`}>
                  {deliveryCharge > 0 ? `₹${deliveryCharge}` : "FREE"}
                </span>
              </div>
              <div className="flex justify-between border-t border-dashed border-border pt-3 text-base font-bold">
                <span>Total</span>
                <span data-testid="cart-total">₹{subtotal + deliveryCharge}</span>
              </div>
              <Button
                data-testid="cart-checkout-button"
                className="w-full rounded-full"
                size="lg"
                onClick={onCheckout}
              >
                Checkout · Pay with PayU
              </Button>
              <button
                data-testid="cart-clear-button"
                onClick={clear}
                className="flex w-full items-center justify-center gap-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:text-destructive"
              >
                <Trash2 className="h-3.5 w-3.5" /> Clear cart
              </button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
};
