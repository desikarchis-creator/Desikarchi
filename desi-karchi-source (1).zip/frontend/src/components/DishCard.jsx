import { Flame, Minus, Plus } from "lucide-react";
import { useCart } from "@/context/CartContext";

const Spice = ({ level }) =>
  level > 0 ? (
    <span className="flex items-center gap-0.5" title={`Spice level ${level}`}>
      {Array.from({ length: level }).map((_, i) => (
        <Flame key={i} className="h-3 w-3 fill-primary/20 text-primary" />
      ))}
    </span>
  ) : null;

export const DishCard = ({ dish }) => {
  const { items, add, setQty } = useCart();
  const inCart = items.find((i) => i.dish.id === dish.id);

  return (
    <div
      data-testid={`dish-card-${dish.id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative h-44 overflow-hidden bg-secondary">
        {dish.image ? (
          <img
            src={dish.image}
            alt={dish.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full items-center justify-center font-display text-3xl text-primary/40">
            {dish.name.charAt(0)}
          </div>
        )}
        <span
          data-testid={`dish-veg-badge-${dish.id}`}
          className={`absolute left-3 top-3 rounded-md border-2 bg-white p-0.5 ${
            dish.veg ? "border-green-700" : "border-red-700"
          }`}
        >
          <span className={`block h-2.5 w-2.5 rounded-full ${dish.veg ? "bg-green-700" : "bg-red-700"}`} />
        </span>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display text-lg font-semibold leading-snug">{dish.name}</h3>
          <Spice level={dish.spice} />
        </div>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{dish.description}</p>
        <div className="mt-auto flex items-center justify-between pt-4">
          <span data-testid={`dish-price-${dish.id}`} className="text-lg font-bold">
            ₹{dish.price}
          </span>
          {inCart ? (
            <div
              data-testid={`dish-qty-stepper-${dish.id}`}
              className="flex items-center gap-1 rounded-full border border-primary/30 bg-primary/5 px-1 py-1"
            >
              <button
                data-testid={`dish-qty-minus-${dish.id}`}
                onClick={() => setQty(dish.id, inCart.qty - 1)}
                className="flex h-7 w-7 items-center justify-center rounded-full text-primary transition-colors hover:bg-primary/10"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span data-testid={`dish-qty-${dish.id}`} className="w-6 text-center text-sm font-bold">
                {inCart.qty}
              </span>
              <button
                data-testid={`dish-qty-plus-${dish.id}`}
                onClick={() => add(dish)}
                className="flex h-7 w-7 items-center justify-center rounded-full text-primary transition-colors hover:bg-primary/10"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              data-testid={`dish-add-button-${dish.id}`}
              onClick={() => add(dish)}
              className="rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:scale-105"
            >
              Add
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
