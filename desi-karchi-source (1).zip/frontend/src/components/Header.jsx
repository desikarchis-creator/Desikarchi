import { Link } from "react-router-dom";
import { MapPin, ShoppingBag, Clock, Truck, UserCog } from "lucide-react";
import { useCart } from "@/context/CartContext";

export const Header = ({ onCartOpen, content }) => {
  const { count } = useCart();
  return (
    <header
      data-testid="site-header"
      className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-xl"
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <a href="#top" data-testid="brand-link" className="flex items-center gap-2.5">
          <img
            src="/logo.png"
            alt="Desi Karchi logo"
            data-testid="brand-logo"
            className="h-12 w-12 rounded-full border-2 border-accent/60 object-cover shadow-sm"
          />
          <div className="leading-tight">
            <p className="font-display text-xl font-bold tracking-tight">Desi Karchi</p>
            <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
              {content.site_tagline}
            </p>
          </div>
        </a>
        <div className="hidden items-center gap-2 md:flex">
          <span
            data-testid="header-pincode-badge"
            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3.5 py-1.5 text-xs font-semibold"
          >
            <MapPin className="h-3.5 w-3.5 text-primary" /> {content.header_pincode_badge}
          </span>
          <span
            data-testid="header-preorder-badge"
            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3.5 py-1.5 text-xs font-semibold"
          >
            <Clock className="h-3.5 w-3.5 text-primary" /> {content.header_preorder_badge}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/track">
            <button
              data-testid="header-track-button"
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2.5 text-sm font-semibold transition-colors duration-200 hover:bg-secondary"
            >
              <Truck className="h-4 w-4 text-primary" /> Track order
            </button>
          </Link>
          <Link to="/admin">
            <button
              data-testid="header-admin-button"
              title="Owner login"
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-4 py-2.5 text-sm font-semibold transition-colors duration-200 hover:bg-secondary"
            >
              <UserCog className="h-4 w-4 text-primary" /> Admin
            </button>
          </Link>
          <button
            data-testid="header-cart-button"
            onClick={onCartOpen}
            className="relative inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-md"
          >
            <ShoppingBag className="h-4 w-4" />
            Cart
            {count > 0 && (
              <span
                data-testid="header-cart-count"
                className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] font-bold text-accent-foreground"
              >
                {count}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
