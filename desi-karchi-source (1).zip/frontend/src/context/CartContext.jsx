import { createContext, useContext, useEffect, useMemo, useState } from "react";

const CartContext = createContext(null);
const STORAGE_KEY = "desikarchi_cart";

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const add = (dish) =>
    setItems((prev) => {
      const found = prev.find((i) => i.dish.id === dish.id);
      if (found) return prev.map((i) => (i.dish.id === dish.id ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { dish, qty: 1 }];
    });

  const setQty = (dishId, qty) =>
    setItems((prev) =>
      qty <= 0
        ? prev.filter((i) => i.dish.id !== dishId)
        : prev.map((i) => (i.dish.id === dishId ? { ...i, qty } : i))
    );

  const clear = () => setItems([]);
  const subtotal = useMemo(() => items.reduce((s, i) => s + i.dish.price * i.qty, 0), [items]);
  const count = useMemo(() => items.reduce((s, i) => s + i.qty, 0), [items]);

  return (
    <CartContext.Provider value={{ items, add, setQty, clear, subtotal, count }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
