import { addDays, format } from "date-fns";

export const nextDates = (count = 7) =>
  Array.from({ length: count }, (_, i) => addDays(new Date(), i + 1));

export const dateLabel = (d) => format(d, "EEE, d MMM");
export const dateValue = (d) => format(d, "yyyy-MM-dd");

// Slots are IST wall-clock times; compare against now+minHours using absolute time.
export const slotsForDate = (dateStr, slots, minHours = 24) => {
  const minTime = new Date(Date.now() + minHours * 3600 * 1000);
  return slots
    .map((s) => ({ ...s, slotDate: new Date(`${dateStr}T${s.start}:00+05:30`) }))
    .filter((s) => s.slotDate >= minTime);
};

export const slotLabel = (s) => `${s.start} – ${s.end}`;
