import asyncio
import hashlib
import hmac
import ipaddress
import logging
import os
import re
import uuid
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

import httpx
from dotenv import load_dotenv
from fastapi import APIRouter, FastAPI, File, Header, HTTPException, Query, Request, UploadFile
from fastapi.responses import RedirectResponse, Response
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

PAYU_KEY = os.environ.get("PAYU_KEY", "").strip()
PAYU_SALT = os.environ.get("PAYU_SALT", "").strip()
PAYU_CHECKOUT_URL = os.environ.get("PAYU_CHECKOUT_URL", "https://test.payu.in/_payment")
PUBLIC_API_URL = os.environ.get("PUBLIC_API_URL", "").rstrip("/")
FRONTEND_URL = os.environ.get("FRONTEND_URL", "").rstrip("/")
ADMIN_PIN = os.environ.get("ADMIN_PIN", "1234")
RECOVERY_CODE = os.environ.get("RECOVERY_CODE", "")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "owner")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")

STORAGE_BASE = (os.environ.get("INTEGRATION_PROXY_URL") or "").strip() or "https://integrations.emergentagent.com"
STORAGE_URL = STORAGE_BASE.rstrip("/") + "/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY", "")
APP_NAME = "desikarchi"
storage_key = None


async def init_storage(force: bool = False):
    global storage_key
    if storage_key and not force:
        return storage_key
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{STORAGE_URL}/init", json={"emergent_key": EMERGENT_KEY})
    resp.raise_for_status()
    storage_key = resp.json()["storage_key"]
    return storage_key


async def put_object(path: str, data: bytes, content_type: str) -> dict:
    key = await init_storage()
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.put(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type},
            data=data,
        )
    if resp.status_code == 404:
        key = await init_storage(force=True)
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.put(
                f"{STORAGE_URL}/objects/{path}",
                headers={"X-Storage-Key": key, "Content-Type": content_type},
                data=data,
            )
    resp.raise_for_status()
    return resp.json()


async def get_object(path: str):
    key = await init_storage()
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.get(f"{STORAGE_URL}/objects/{path}", headers={"X-Storage-Key": key})
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")

EMAIL_BASE_URL = "https://integrations.emergentagent.com"
EMAIL_KEY = os.environ.get("EMERGENT_EMAIL_KEY", "")
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "Desi Karchi")
EMAIL_REPLY_TO = os.environ.get("EMAIL_REPLY_TO")
OWNER_EMAIL = os.environ.get("OWNER_EMAIL", "")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

DEFAULT_PINCODES = ["110019"]
MIN_ORDER_HOURS = 24
IST = timezone(timedelta(hours=5, minutes=30))
DELIVERY_SLOTS = [
    {"start": "11:00", "end": "13:00"},
    {"start": "13:00", "end": "15:00"},
    {"start": "17:00", "end": "19:00"},
    {"start": "19:00", "end": "21:00"},
]

app = FastAPI()
api_router = APIRouter(prefix="/api")


def now():
    return datetime.now(timezone.utc)


def money(value) -> str:
    return format(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), ".2f")


def sha512(value: str) -> str:
    return hashlib.sha512(value.encode("utf-8")).hexdigest()


def request_hash(*, txnid, amount, productinfo, firstname, email, udf1=""):
    parts = [PAYU_KEY, txnid, amount, productinfo, firstname, email,
             udf1, "", "", "", "", "", "", "", "", "", PAYU_SALT]
    return sha512("|".join(parts))


def response_hash(fields: dict) -> str:
    parts = [
        PAYU_SALT, fields.get("status", ""), "", "", "", "", "",
        fields.get("udf5", ""), fields.get("udf4", ""), fields.get("udf3", ""),
        fields.get("udf2", ""), fields.get("udf1", ""), fields.get("email", ""),
        fields.get("firstname", ""), fields.get("productinfo", ""),
        fields.get("amount", ""), fields.get("txnid", ""), fields.get("key", ""),
    ]
    if "additionalCharges" in fields:
        parts.insert(0, fields["additionalCharges"])
    return sha512("|".join(parts))


_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.IGNORECASE)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r}")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r}")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r}")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != real link host {real!r}")


async def send_email(*, to: str, subject: str, html: str, reply_to: str | None = None) -> str | None:
    _assert_safe_email(subject, html)
    payload = {"to": [to], "subject": subject, "html": html, "from_name": EMAIL_FROM_NAME}
    if reply_to or EMAIL_REPLY_TO:
        payload["contact_email"] = reply_to or EMAIL_REPLY_TO
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"{EMAIL_BASE_URL}/api/v1/email/send",
            headers={"X-Email-Key": EMAIL_KEY},
            json=payload,
        )
    resp.raise_for_status()
    return resp.json().get("id")


def _order_email_html(order: dict, payment_line: str) -> str:
    items_html = "".join(
        f'<tr><td style="padding:6px 12px;border-bottom:1px solid #eee">{i["qty"]}&times; {escape(i["name"])}</td>'
        f'<td style="padding:6px 12px;border-bottom:1px solid #eee;text-align:right">&#8377;{i["line_total"]}</td></tr>'
        for i in order["items"]
    )
    c = order["customer"]
    return (
        '<table role="presentation" width="100%" style="font-family:Arial,sans-serif;max-width:560px;margin:auto">'
        '<tr><td style="padding:24px;background:#D42B33;color:#ffffff;border-radius:12px 12px 0 0">'
        '<h2 style="margin:0">New order &mdash; Desi Karchi</h2>'
        f'<p style="margin:6px 0 0">{escape(payment_line)}</p></td></tr>'
        '<tr><td style="padding:20px;border:1px solid #eee;border-radius:0 0 12px 12px">'
        f'<p><strong>Order:</strong> #{escape(order["id"][:8].upper())} &nbsp;|&nbsp; '
        f'<strong>Total:</strong> &#8377;{escape(str(order["amount"]))}</p>'
        f'<p><strong>Delivery slot:</strong> {escape(order["delivery_date"])} &middot; '
        f'{escape(order["slot_start"])}&ndash;{escape(order["slot_end"])}</p>'
        f'<p><strong>Customer:</strong> {escape(c["name"])} &middot; {escape(c["phone"])}<br/>'
        f'<strong>Address:</strong> {escape(c["address"])}, {escape(c["pincode"])}</p>'
        f'<table role="presentation" width="100%" style="border-collapse:collapse">{items_html}</table>'
        f'<p style="margin-top:18px"><a href="{FRONTEND_URL}/admin" '
        'style="background:#D42B33;color:#ffffff;padding:10px 18px;border-radius:20px;text-decoration:none">'
        'Open owner panel</a></p>'
        '<p style="font-size:12px;color:#888;margin-top:20px">Sent by Desi Karchi order alerts. '
        'We never ask for your password or card details by email.</p>'
        '</td></tr></table>'
    )


async def notify_owner_order(order: dict, payment_line: str, subject_suffix: str):
    if not (EMAIL_KEY and OWNER_EMAIL):
        return
    try:
        email_id = await send_email(
            to=OWNER_EMAIL,
            subject=f"Desi Karchi: new order #{order['id'][:8].upper()} - {subject_suffix}",
            html=_order_email_html(order, payment_line),
        )
        logger.info("Order email sent for %s (email_id=%s)", order.get("id"), email_id)
    except Exception:
        logger.exception("Owner order email failed for order %s", order.get("id"))


def _customer_email_html(order: dict, payment_line: str) -> str:
    items_html = "".join(
        f'<tr><td style="padding:6px 12px;border-bottom:1px solid #eee">{i["qty"]}&times; {escape(i["name"])}</td>'
        f'<td style="padding:6px 12px;border-bottom:1px solid #eee;text-align:right">&#8377;{i["line_total"]}</td></tr>'
        for i in order["items"]
    )
    c = order["customer"]
    return (
        '<table role="presentation" width="100%" style="font-family:Arial,sans-serif;max-width:560px;margin:auto">'
        '<tr><td style="padding:24px;background:#D42B33;color:#ffffff;border-radius:12px 12px 0 0">'
        '<h2 style="margin:0">Thank you for your order!</h2>'
        f'<p style="margin:6px 0 0">{escape(payment_line)}</p></td></tr>'
        '<tr><td style="padding:20px;border:1px solid #eee;border-radius:0 0 12px 12px">'
        f'<p>Hi {escape(c["name"].split()[0])}, your Desi Karchi order is booked. '
        'We cook fresh against every order and will deliver hot in your chosen slot.</p>'
        f'<p><strong>Order:</strong> #{escape(order["id"][:8].upper())} &nbsp;|&nbsp; '
        f'<strong>Total:</strong> &#8377;{escape(str(order["amount"]))}</p>'
        f'<p><strong>Delivery slot:</strong> {escape(order["delivery_date"])} &middot; '
        f'{escape(order["slot_start"])}&ndash;{escape(order["slot_end"])}</p>'
        f'<p><strong>Deliver to:</strong> {escape(c["address"])}, {escape(c["pincode"])}<br/>'
        f'<strong>Phone:</strong> {escape(c["phone"])}</p>'
        f'<table role="presentation" width="100%" style="border-collapse:collapse">{items_html}</table>'
        '<p style="margin-top:18px">Questions about your order? Just reply to this email.</p>'
        '<p style="font-size:12px;color:#888;margin-top:16px">Desi Karchi, Kalkaji, New Delhi 110019. '
        'We never ask for your password or card details by email.</p>'
        '</td></tr></table>'
    )


async def notify_customer_order(order: dict, payment_line: str, subject_suffix: str):
    to = (order.get("customer") or {}).get("email") or ""
    if not (EMAIL_KEY and "@" in to):
        return
    try:
        email_id = await send_email(
            to=to,
            subject=f"Your Desi Karchi order #{order['id'][:8].upper()} - {subject_suffix}",
            html=_customer_email_html(order, payment_line),
        )
        logger.info("Customer email sent for %s (email_id=%s)", order.get("id"), email_id)
    except Exception:
        logger.exception("Customer order email failed for order %s", order.get("id"))


class DishIn(BaseModel):
    name: str
    description: str = ""
    price: float
    category: str = "Mains"
    image: str | None = None
    veg: bool = True
    spice: int = 1


class CartItem(BaseModel):
    dish_id: str
    qty: int = Field(gt=0, le=20)


class CustomerIn(BaseModel):
    name: str
    phone: str
    email: str
    address: str
    pincode: str


class OrderIn(BaseModel):
    items: list[CartItem]
    customer: CustomerIn
    delivery_date: str
    slot_start: str
    slot_end: str


class PayuStartIn(BaseModel):
    order_id: str


SEED_DISHES = [
    {"name": "Kadhai Paneer", "description": "Cottage cheese tossed with charred capsicum, onion petals & freshly pounded kadhai masala.", "price": 240, "category": "Mains", "veg": True, "spice": 2,
     "image": "https://images.pexels.com/photos/29684993/pexels-photo-29684993.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"},
    {"name": "Butter Chicken", "description": "Tandoor-kissed chicken simmered in a silky tomato-makhani gravy, finished with cream.", "price": 320, "category": "Mains", "veg": False, "spice": 1,
     "image": "https://images.unsplash.com/photo-1585937421612-70a008356fbe?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MTN8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjdXJyeSUyMGthZGhhaSUyMGZvb2R8ZW58MHx8fHwxNzg5NTM3ODEwfDA&ixlib=rb-4.1.0&q=85"},
    {"name": "Dum Aloo Kalkaji Style", "description": "Baby potatoes slow-cooked in a spicy yoghurt-onion gravy, our neighbourhood favourite.", "price": 210, "category": "Mains", "veg": True, "spice": 3,
     "image": "https://images.pexels.com/photos/33643298/pexels-photo-33643298.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"},
    {"name": "Dal Makhani", "description": "Black urad simmered overnight on a low flame with butter, cream & a whisper of smoke.", "price": 190, "category": "Dal & Rice", "veg": True, "spice": 1,
     "image": "https://images.unsplash.com/photo-1596797038530-2c107229654b?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MTN8MHwxfHNlYXJjaHw0fHxpbmRpYW4lMjBjdXJyeSUyMGthZGhhaSUyMGZvb2R8ZW58MHx8fHwxNzg5NTM3ODEwfDA&ixlib=rb-4.1.0&q=85"},
    {"name": "Desi Karchi Special Thali", "description": "Two seasonal sabzis, dal, rice, 3 rotis, salad, papad & a small dessert — the full works.", "price": 349, "category": "Thali", "veg": True, "spice": 2,
     "image": "https://images.unsplash.com/photo-1728910156510-77488f19b152?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MTN8MHwxfHNlYXJjaHwyfHxpbmRpYW4lMjBjdXJyeSUyMGthZGhhaSUyMGZvb2R8ZW58MHx8fHwxNzg5NTM3ODEwfDA&ixlib=rb-4.1.0&q=85"},
    {"name": "Chicken Curry & Rice Combo", "description": "Homestyle chicken curry with steamed basmati rice and a kachumber salad.", "price": 280, "category": "Combos", "veg": False, "spice": 2,
     "image": "https://images.unsplash.com/photo-1631452180539-96aca7d48617?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MTN8MHwxfHNlYXJjaHwzfHxpbmRpYW4lMjBjdXJyeSUyMGthZGhhaSUyMGZvb2R8ZW58MHx8fHwxNzg5NTM3ODEwfDA&ixlib=rb-4.1.0&q=85"},
]


@api_router.get("/")
async def root():
    return {"message": "Desi Karchi API"}


@api_router.get("/config")
async def get_config():
    return {
        "pincodes": await get_pincodes(),
        "delivery_charge": await get_delivery_charge(),
        "area": "Kalkaji, New Delhi",
        "min_hours": MIN_ORDER_HOURS,
        "slots": DELIVERY_SLOTS,
        "payu_ready": bool(PAYU_KEY and PAYU_SALT),
    }


DEFAULT_CONTENT = {
    "site_tagline": "Ghar jaisa swad, dil se banaa",
    "header_pincode_badge": "Kalkaji · 110019",
    "header_preorder_badge": "Order 24 hrs ahead",
    "hero_badge": "Kalkaji, New Delhi only",
    "hero_title_1": "Slow-cooked desi flavours,",
    "hero_title_highlight": "pre-ordered",
    "hero_title_2": "for tomorrow.",
    "hero_subtitle": "Desi Karchi cooks fresh against your order — never reheated, never rushed. Pick your dishes, choose a delivery slot at least 24 hours ahead, and we bring the kadhai to your doorstep in Kalkaji 110019.",
    "pincode_widget_title": "Do we deliver to you?",
    "pincode_widget_text": "We currently serve only pincode 110019 (Kalkaji).",
    "menu_kicker": "Fresh from the kadhai",
    "menu_title": "The Menu",
    "step1_title": "Pick your dishes",
    "step1_desc": "Browse the kadhai menu and add favourites to your cart.",
    "step2_title": "Choose a slot 24 hrs ahead",
    "step2_desc": "We cook fresh against every order, so delivery slots start at least 24 hours from now.",
    "step3_title": "Pay & relax",
    "step3_desc": "Secure PayU checkout. Hot food arrives at your Kalkaji doorstep in your slot.",
    "footer_text": "Delivering only in Kalkaji, New Delhi · 110019",
}


@api_router.get("/content")
async def get_content():
    doc = await db.settings.find_one({"key": "site_content"}, {"_id": 0})
    stored = doc["value"] if doc else {}
    return {**DEFAULT_CONTENT, **{k: v for k, v in stored.items() if k in DEFAULT_CONTENT}}


class ContentUpdateIn(BaseModel):
    updates: dict


@api_router.put("/content")
async def update_content(body: ContentUpdateIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid credentials")
    clean = {k: str(v)[:500] for k, v in body.updates.items() if k in DEFAULT_CONTENT}
    await db.settings.update_one(
        {"key": "site_content"},
        {"$set": {"key": "site_content", "value": clean}},
        upsert=True,
    )
    return await get_content()


async def get_pincodes():
    doc = await db.settings.find_one({"key": "delivery_pincodes"}, {"_id": 0})
    return doc["value"] if doc else DEFAULT_PINCODES


class PincodesIn(BaseModel):
    pincodes: list[str]


@api_router.put("/admin/pincodes")
async def set_pincodes(body: PincodesIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid credentials")
    clean = sorted({p.strip() for p in body.pincodes if re.fullmatch(r"\d{6}", p.strip())})
    if not clean:
        raise HTTPException(422, "At least one valid 6-digit pincode is required")
    await db.settings.update_one(
        {"key": "delivery_pincodes"},
        {"$set": {"key": "delivery_pincodes", "value": clean}},
        upsert=True,
    )
    return {"pincodes": clean}


async def get_delivery_charge():
    doc = await db.settings.find_one({"key": "delivery_charge"}, {"_id": 0})
    return float(doc["value"]) if doc else 0.0


class DeliveryChargeIn(BaseModel):
    charge: float


@api_router.put("/admin/delivery-charge")
async def set_delivery_charge(body: DeliveryChargeIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid credentials")
    if not (0 <= body.charge <= 500):
        raise HTTPException(422, "Delivery charge must be between 0 and 500")
    await db.settings.update_one(
        {"key": "delivery_charge"},
        {"$set": {"key": "delivery_charge", "value": body.charge}},
        upsert=True,
    )
    return {"delivery_charge": body.charge}


@api_router.get("/menu")
async def get_menu():
    dishes = await db.dishes.find({}, {"_id": 0}).to_list(500)
    return dishes


@api_router.post("/menu", status_code=201)
async def add_dish(dish: DishIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid owner PIN")
    if not dish.name.strip() or dish.price <= 0:
        raise HTTPException(422, "Dish name and a valid price are required")
    doc = dish.model_dump()
    doc["id"] = uuid.uuid4().hex
    doc["created_at"] = now().isoformat()
    await db.dishes.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api_router.delete("/menu/{dish_id}")
async def remove_dish(dish_id: str, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid owner PIN")
    result = await db.dishes.delete_one({"id": dish_id})
    if result.deleted_count == 0:
        raise HTTPException(404, "Dish not found")
    return {"deleted": True}


@api_router.put("/menu/{dish_id}")
async def update_dish(dish_id: str, dish: DishIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid owner PIN")
    if not dish.name.strip() or dish.price <= 0:
        raise HTTPException(422, "Dish name and a valid price are required")
    result = await db.dishes.update_one({"id": dish_id}, {"$set": dish.model_dump()})
    if result.matched_count == 0:
        raise HTTPException(404, "Dish not found")
    return await db.dishes.find_one({"id": dish_id}, {"_id": 0})


async def get_admin_password():
    doc = await db.settings.find_one({"key": "admin_password"}, {"_id": 0})
    if doc:
        return doc["value"]
    old = await db.settings.find_one({"key": "admin_pin"}, {"_id": 0})
    if old:
        return old["value"]
    return ADMIN_PASSWORD or ADMIN_PIN


get_admin_pin = get_admin_password


class AdminLoginIn(BaseModel):
    username: str
    password: str


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str


class PasswordResetIn(BaseModel):
    recovery_code: str
    new_password: str


def validate_new_password(password: str):
    if not (4 <= len(password or "") <= 30):
        raise HTTPException(422, "Password must be 4-30 characters")


@api_router.post("/admin/login")
async def admin_login(body: AdminLoginIn):
    if body.username.strip().lower() != ADMIN_USERNAME.lower() or body.password != await get_admin_password():
        raise HTTPException(401, "Invalid username or password")
    return {"ok": True}


@api_router.post("/admin/change-password")
async def change_password(body: PasswordChangeIn):
    if body.current_password != await get_admin_password():
        raise HTTPException(401, "Current password is incorrect")
    validate_new_password(body.new_password)
    await db.settings.update_one(
        {"key": "admin_password"},
        {"$set": {"key": "admin_password", "value": body.new_password}},
        upsert=True,
    )
    return {"ok": True}


@api_router.post("/admin/reset-password")
async def reset_password(body: PasswordResetIn):
    if not RECOVERY_CODE or body.recovery_code != RECOVERY_CODE:
        raise HTTPException(401, "Invalid recovery code")
    validate_new_password(body.new_password)
    await db.settings.update_one(
        {"key": "admin_password"},
        {"$set": {"key": "admin_password", "value": body.new_password}},
        upsert=True,
    )
    return {"ok": True}


@api_router.get("/admin/orders")
async def list_orders(x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid owner PIN")
    return await db.orders.find({}, {"_id": 0, "payu_response": 0}).sort("created_at", -1).to_list(200)


FULFILLMENT_STATUSES = ["order_received", "prepared", "out_for_delivery", "delivered"]


class StatusIn(BaseModel):
    status: str


@api_router.put("/admin/orders/{order_id}/status")
async def set_order_status(order_id: str, body: StatusIn, x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid credentials")
    if body.status not in FULFILLMENT_STATUSES:
        raise HTTPException(422, "Invalid status")
    result = await db.orders.update_one(
        {"id": order_id, "payment_status": "success"},
        {"$set": {"status": body.status, "updated_at": now().isoformat()}},
    )
    if result.matched_count == 0:
        raise HTTPException(404, "Paid order not found")
    return {"id": order_id, "status": body.status}


@api_router.get("/orders/{order_id}/track")
async def track_order(order_id: str, phone: str = Query(default="")):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0, "payu_response": 0})
    if not order and len(order_id.strip()) >= 6:
        order = await db.orders.find_one(
            {"id": {"$regex": f"^{re.escape(order_id.strip())}"}},
            {"_id": 0, "payu_response": 0},
        )
    if not order or not phone or order["customer"]["phone"][-10:] != phone.strip()[-10:]:
        raise HTTPException(404, "Order not found - check order ID and phone number")
    return {
        "id": order["id"],
        "status": order["status"],
        "payment_status": order["payment_status"],
        "items": order["items"],
        "amount": order["amount"],
        "delivery_date": order["delivery_date"],
        "slot_start": order["slot_start"],
        "slot_end": order["slot_end"],
        "customer_name": order["customer"]["name"],
    }


ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_IMAGE_BYTES = 5 * 1024 * 1024


@api_router.post("/upload", status_code=201)
async def upload_image(file: UploadFile = File(...), x_admin_pin: str = Header(default="")):
    if x_admin_pin != await get_admin_pin():
        raise HTTPException(401, "Invalid credentials")
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(422, "Only JPG, PNG, WEBP or GIF images are allowed")
    data = await file.read()
    if not data:
        raise HTTPException(422, "Empty file")
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(422, "Image must be under 5MB")
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else "jpg"
    path = f"{APP_NAME}/uploads/dishes/{uuid.uuid4().hex}.{ext}"
    result = await put_object(path, data, file.content_type)
    await db.files.insert_one({
        "id": uuid.uuid4().hex,
        "storage_path": result["path"],
        "original_filename": file.filename,
        "content_type": file.content_type,
        "size": result["size"],
        "is_deleted": False,
        "created_at": now().isoformat(),
    })
    return {"url": f"{PUBLIC_API_URL}/api/files/{result['path']}", "path": result["path"]}


@api_router.get("/files/{path:path}")
async def download_file(path: str):
    record = await db.files.find_one({"storage_path": path, "is_deleted": False}, {"_id": 0})
    if not record:
        raise HTTPException(404, "File not found")
    data, content_type = await get_object(path)
    return Response(content=data, media_type=record.get("content_type", content_type))


def validate_slot(delivery_date: str, slot_start: str, slot_end: str):
    if not any(s["start"] == slot_start and s["end"] == slot_end for s in DELIVERY_SLOTS):
        raise HTTPException(422, "Invalid delivery slot")
    try:
        h, m = map(int, slot_start.split(":"))
        slot_dt = datetime.strptime(delivery_date, "%Y-%m-%d").replace(
            hour=h, minute=m, tzinfo=IST
        )
    except ValueError:
        raise HTTPException(422, "Invalid delivery date")
    min_dt = datetime.now(IST) + timedelta(hours=MIN_ORDER_HOURS)
    if slot_dt < min_dt:
        raise HTTPException(422, f"Delivery must be at least {MIN_ORDER_HOURS} hours from now")
    if slot_dt.date() > (datetime.now(IST) + timedelta(days=7)).date():
        raise HTTPException(422, "Delivery can be booked at most 7 days ahead")


@api_router.post("/orders", status_code=201)
async def create_order(body: OrderIn):
    pincodes = await get_pincodes()
    if body.customer.pincode not in pincodes:
        raise HTTPException(422, f"We deliver only in: {', '.join(pincodes)}")
    if "@" not in (body.customer.email or ""):
        raise HTTPException(422, "Please provide a valid email for order confirmation")
    if not body.items:
        raise HTTPException(422, "Cart is empty")
    validate_slot(body.delivery_date, body.slot_start, body.slot_end)

    dish_ids = [i.dish_id for i in body.items]
    dishes = await db.dishes.find({"id": {"$in": dish_ids}}, {"_id": 0}).to_list(500)
    by_id = {d["id"]: d for d in dishes}

    order_items = []
    total = Decimal(0)
    for item in body.items:
        dish = by_id.get(item.dish_id)
        if not dish:
            raise HTTPException(422, "A dish in your cart is no longer available")
        line = Decimal(str(dish["price"])) * item.qty
        total += line
        order_items.append({
            "dish_id": dish["id"], "name": dish["name"],
            "price": dish["price"], "qty": item.qty, "line_total": float(line),
        })

    delivery_charge = await get_delivery_charge()
    order_id = uuid.uuid4().hex
    doc = {
        "id": order_id,
        "items": order_items,
        "subtotal": money(total),
        "delivery_charge": money(delivery_charge),
        "amount": money(total + Decimal(str(delivery_charge))),
        "currency": "INR",
        "customer": body.customer.model_dump(),
        "delivery_date": body.delivery_date,
        "slot_start": body.slot_start,
        "slot_end": body.slot_end,
        "status": "payment_pending",
        "payment_status": "pending",
        "payu_txnid": None,
        "payu_mihpayid": None,
        "created_at": now().isoformat(),
        "updated_at": now().isoformat(),
    }
    await db.orders.insert_one(doc)
    doc.pop("_id", None)
    asyncio.create_task(notify_owner_order(doc, "Payment pending - customer is at PayU checkout.", "awaiting payment"))
    asyncio.create_task(notify_customer_order(doc, "We have received your order - please complete the payment to confirm it.", "order received"))
    return doc


@api_router.get("/orders/{order_id}")
async def get_order(order_id: str):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0, "payu_response": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    return order


@api_router.get("/orders/{order_id}/payment-status")
async def payment_status(order_id: str):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0, "payment_status": 1, "status": 1})
    if not order:
        raise HTTPException(404, "Order not found")
    return order


@api_router.post("/payments/payu/start")
async def start_payment(body: PayuStartIn):
    if not (PAYU_KEY and PAYU_SALT):
        raise HTTPException(503, "PayU is not configured yet. Owner needs to add PAYU_KEY and PAYU_SALT.")
    order = await db.orders.find_one({"id": body.order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    if order.get("payment_status") == "success":
        raise HTTPException(409, "Order is already paid")

    customer = order["customer"]
    amount = money(order["amount"])
    txnid = "dk" + uuid.uuid4().hex[:18]
    productinfo = f"Desi Karchi order {order['id'][:8]}"
    firstname = customer["name"].split()[0]
    email = customer["email"]
    udf1 = order["id"]
    digest = request_hash(txnid=txnid, amount=amount, productinfo=productinfo,
                          firstname=firstname, email=email, udf1=udf1)

    surl = f"{PUBLIC_API_URL}/api/payments/payu/success"
    furl = f"{PUBLIC_API_URL}/api/payments/payu/failure"
    fields = {
        "key": PAYU_KEY, "txnid": txnid, "amount": amount,
        "productinfo": productinfo, "firstname": firstname, "email": email,
        "phone": customer["phone"],
        "surl": surl, "furl": furl, "curl": furl,
        "udf1": udf1, "udf2": "", "udf3": "", "udf4": "", "udf5": "",
        "hash": digest,
    }
    await db.orders.update_one(
        {"id": order["id"]},
        {"$set": {"payu_txnid": txnid, "payment_status": "pending",
                  "status": "payment_pending", "updated_at": now().isoformat()}},
    )
    return {"checkout_url": PAYU_CHECKOUT_URL, "fields": fields}


async def handle_payu_callback(request: Request):
    form = await request.form()
    fields = {str(k): str(v) for k, v in form.items()}
    received = fields.get("hash", "")
    expected = response_hash(fields)

    if not received or not hmac.compare_digest(received.lower(), expected.lower()):
        raise HTTPException(400, "Invalid PayU response hash")

    order = await db.orders.find_one({"payu_txnid": fields.get("txnid", "")})
    if not order:
        raise HTTPException(404, "Unknown transaction")

    if fields.get("key") != PAYU_KEY or fields.get("amount") != money(order["amount"]):
        raise HTTPException(400, "Callback does not match order")

    if order.get("payment_status") == "success":
        return RedirectResponse(f"{FRONTEND_URL}/payment-result?order_id={order['id']}", status_code=303)

    paid = fields.get("status", "").lower() == "success"
    await db.orders.update_one(
        {"id": order["id"]},
        {"$set": {
            "payment_status": "success" if paid else "failure",
            "status": "order_received" if paid else "payment_failed",
            "payu_mihpayid": fields.get("mihpayid"),
            "payu_status": fields.get("status", ""),
            "updated_at": now().isoformat(),
        }},
    )
    if paid:
        asyncio.create_task(notify_owner_order(order, "Payment received via PayU.", "payment confirmed"))
        asyncio.create_task(notify_customer_order(order, "Payment received - your order is confirmed. See you at delivery time!", "payment confirmed"))
    return RedirectResponse(f"{FRONTEND_URL}/payment-result?order_id={order['id']}", status_code=303)


@api_router.post("/payments/payu/success")
async def payu_success(request: Request):
    return await handle_payu_callback(request)


@api_router.post("/payments/payu/failure")
async def payu_failure(request: Request):
    return await handle_payu_callback(request)


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def seed_menu():
    try:
        await init_storage()
        logger.info("Object storage initialized")
    except Exception:
        logger.exception("Object storage init failed")
    await db.orders.create_index("payu_txnid")
    if await db.dishes.count_documents({}) == 0:
        for d in SEED_DISHES:
            doc = {**d, "id": uuid.uuid4().hex, "created_at": now().isoformat()}
            await db.dishes.insert_one(doc)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
