"""Desi Karchi backend API tests."""
import os
from datetime import datetime, timedelta, timezone

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://karchi-order.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
IST = timezone(timedelta(hours=5, minutes=30))
ADMIN_PIN = "1234"


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _future_slot():
    """Return (date_str, slot_start, slot_end) that is >24h ahead in IST."""
    target = datetime.now(IST) + timedelta(days=2)
    return target.strftime("%Y-%m-%d"), "19:00", "21:00"


# --- Config ---
def test_config(session):
    r = session.get(f"{API}/config")
    assert r.status_code == 200
    data = r.json()
    assert data["pincode"] == "110019"
    assert data["min_hours"] == 24
    assert isinstance(data["payu_ready"], bool)
    assert isinstance(data["slots"], list) and len(data["slots"]) >= 1


# --- Menu ---
def test_menu_list(session):
    r = session.get(f"{API}/menu")
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    assert len(data) >= 1
    assert "id" in data[0] and "price" in data[0]


def test_menu_add_requires_pin(session):
    r = session.post(f"{API}/menu", json={"name": "X", "price": 10})
    assert r.status_code == 401


def test_menu_add_and_delete_with_pin(session):
    payload = {"name": "TEST_Paneer Tikka", "price": 149, "category": "Starters", "veg": True, "spice": 2}
    r = session.post(f"{API}/menu", json=payload, headers={"x-admin-pin": ADMIN_PIN})
    assert r.status_code == 201, r.text
    dish = r.json()
    assert dish["name"] == payload["name"]
    assert "id" in dish and "_id" not in dish

    # Verify appears in list
    r2 = session.get(f"{API}/menu")
    ids = [d["id"] for d in r2.json()]
    assert dish["id"] in ids

    # Delete without PIN -> 401
    rdel_noauth = session.delete(f"{API}/menu/{dish['id']}")
    assert rdel_noauth.status_code == 401

    # Delete with PIN
    rdel = session.delete(f"{API}/menu/{dish['id']}", headers={"x-admin-pin": ADMIN_PIN})
    assert rdel.status_code == 200

    # Deleting again -> 404
    rdel2 = session.delete(f"{API}/menu/{dish['id']}", headers={"x-admin-pin": ADMIN_PIN})
    assert rdel2.status_code == 404


def test_admin_verify(session):
    assert session.get(f"{API}/admin/verify", headers={"x-admin-pin": "0000"}).status_code == 401
    assert session.get(f"{API}/admin/verify", headers={"x-admin-pin": ADMIN_PIN}).status_code == 200


# --- Orders ---
def _valid_order_payload(session, pincode="110019"):
    menu = session.get(f"{API}/menu").json()
    dish = menu[0]
    date_str, ss, se = _future_slot()
    return {
        "items": [{"dish_id": dish["id"], "qty": 2}],
        "customer": {"name": "Test User", "phone": "9876543210", "address": "12 Test Lane, Kalkaji", "pincode": pincode},
        "delivery_date": date_str,
        "slot_start": ss,
        "slot_end": se,
    }, dish


def test_order_wrong_pincode(session):
    body, _ = _valid_order_payload(session, pincode="110020")
    r = session.post(f"{API}/orders", json=body)
    assert r.status_code == 422


def test_order_slot_too_soon(session):
    body, _ = _valid_order_payload(session)
    # Set to today, first slot -> should fail (< 24h)
    body["delivery_date"] = datetime.now(IST).strftime("%Y-%m-%d")
    body["slot_start"] = "11:00"
    body["slot_end"] = "13:00"
    r = session.post(f"{API}/orders", json=body)
    assert r.status_code == 422


def test_order_create_and_get(session):
    body, dish = _valid_order_payload(session)
    r = session.post(f"{API}/orders", json=body)
    assert r.status_code == 201, r.text
    order = r.json()
    assert order["status"] == "payment_pending"
    assert order["payment_status"] == "pending"
    # server-computed amount
    expected = f"{dish['price'] * 2:.2f}"
    assert order["amount"] == expected
    assert "_id" not in order

    # GET verify persistence
    r2 = session.get(f"{API}/orders/{order['id']}")
    assert r2.status_code == 200
    assert r2.json()["id"] == order["id"]

    # payment-status endpoint
    r3 = session.get(f"{API}/orders/{order['id']}/payment-status")
    assert r3.status_code == 200
    assert r3.json()["payment_status"] == "pending"


def test_order_not_found(session):
    r = session.get(f"{API}/orders/does-not-exist")
    assert r.status_code == 404


# --- PayU ---
def test_payu_start_ok_or_503(session):
    body, _ = _valid_order_payload(session)
    r = session.post(f"{API}/orders", json=body)
    order_id = r.json()["id"]
    rp = session.post(f"{API}/payments/payu/start", json={"order_id": order_id})
    assert rp.status_code in (200, 503)
    if rp.status_code == 200:
        data = rp.json()
        assert "checkout_url" in data
        assert "fields" in data
        for k in ("key", "txnid", "amount", "hash", "surl", "furl"):
            assert k in data["fields"]
