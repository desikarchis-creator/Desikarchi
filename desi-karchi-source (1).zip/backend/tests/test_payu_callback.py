"""Simulated PayU callback test to validate the response_hash fix."""
import hashlib
import os
from datetime import datetime, timedelta, timezone

import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://karchi-order.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
IST = timezone(timedelta(hours=5, minutes=30))
PAYU_KEY = "zmSwgE"
PAYU_SALT = "9AzoLt9b04BcF7etMBpnZqc5BqOF13Ob"


def sha512(s: str) -> str:
    return hashlib.sha512(s.encode("utf-8")).hexdigest()


def _future_slot():
    target = datetime.now(IST) + timedelta(days=2)
    return target.strftime("%Y-%m-%d"), "19:00", "21:00"


@pytest.fixture(scope="module")
def order_and_txn():
    s = requests.Session()
    menu = s.get(f"{API}/menu").json()
    dish = menu[0]
    date_str, ss, se = _future_slot()
    body = {
        "items": [{"dish_id": dish["id"], "qty": 1}],
        "customer": {"name": "PayU Sim", "phone": "9876543299",
                     "address": "B-7 Kalkaji", "pincode": "110019"},
        "delivery_date": date_str, "slot_start": ss, "slot_end": se,
    }
    r = s.post(f"{API}/orders", json=body)
    assert r.status_code == 201
    order = r.json()
    rp = s.post(f"{API}/payments/payu/start", json={"order_id": order["id"]})
    assert rp.status_code == 200
    fields = rp.json()["fields"]
    return order, fields


def test_success_callback_valid_hash(order_and_txn):
    order, fields = order_and_txn
    txnid = fields["txnid"]
    amount = fields["amount"]
    productinfo = fields["productinfo"]
    firstname = fields["firstname"]
    email = fields["email"]
    udf1 = fields["udf1"]
    # Reverse hash NO additionalCharges: SALT|status|||||udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key
    parts = [PAYU_SALT, "success", "", "", "", "", "",
             "", "", "", "", udf1, email, firstname, productinfo, amount, txnid, PAYU_KEY]
    digest = sha512("|".join(parts))
    form = {
        "key": PAYU_KEY, "txnid": txnid, "amount": amount,
        "productinfo": productinfo, "firstname": firstname, "email": email,
        "udf1": udf1, "udf2": "", "udf3": "", "udf4": "", "udf5": "",
        "status": "success", "mihpayid": "SIMTEST123", "hash": digest,
    }
    # Do NOT follow redirects
    r = requests.post(f"{API}/payments/payu/success", data=form, allow_redirects=False)
    assert r.status_code == 303, f"Expected 303, got {r.status_code}: {r.text}"
    assert "/payment-result?order_id=" in r.headers.get("location", "")

    # Order should now be confirmed
    r2 = requests.get(f"{API}/orders/{order['id']}")
    body = r2.json()
    assert body["status"] == "confirmed"
    assert body["payment_status"] == "success"
    assert body["payu_mihpayid"] == "SIMTEST123"


def test_success_callback_idempotent(order_and_txn):
    order, fields = order_and_txn
    # Repeat the same successful callback — should short-circuit still 303
    txnid = fields["txnid"]; amount = fields["amount"]; productinfo = fields["productinfo"]
    firstname = fields["firstname"]; email = fields["email"]; udf1 = fields["udf1"]
    parts = [PAYU_SALT, "success", "", "", "", "", "",
             "", "", "", "", udf1, email, firstname, productinfo, amount, txnid, PAYU_KEY]
    digest = sha512("|".join(parts))
    form = {
        "key": PAYU_KEY, "txnid": txnid, "amount": amount,
        "productinfo": productinfo, "firstname": firstname, "email": email,
        "udf1": udf1, "udf2": "", "udf3": "", "udf4": "", "udf5": "",
        "status": "success", "mihpayid": "SIMTEST123", "hash": digest,
    }
    r = requests.post(f"{API}/payments/payu/success", data=form, allow_redirects=False)
    assert r.status_code == 303


def test_bad_hash_rejected():
    r = requests.post(f"{API}/payments/payu/success",
                      data={"txnid": "x", "hash": "deadbeef", "status": "success",
                            "key": PAYU_KEY, "amount": "10.00"})
    assert r.status_code in (400, 404)


def test_callback_with_additionalCharges():
    """Verify hash still validates when additionalCharges is present (edge case)."""
    s = requests.Session()
    menu = s.get(f"{API}/menu").json()
    dish = menu[0]
    date_str, ss, se = _future_slot()
    body = {
        "items": [{"dish_id": dish["id"], "qty": 1}],
        "customer": {"name": "AddCharge", "phone": "9876543298",
                     "address": "B-7 Kalkaji", "pincode": "110019"},
        "delivery_date": date_str, "slot_start": ss, "slot_end": se,
    }
    order = s.post(f"{API}/orders", json=body).json()
    fields = s.post(f"{API}/payments/payu/start", json={"order_id": order["id"]}).json()["fields"]

    ac = "5.00"
    txnid = fields["txnid"]; amount = fields["amount"]; productinfo = fields["productinfo"]
    firstname = fields["firstname"]; email = fields["email"]; udf1 = fields["udf1"]
    parts = [ac, PAYU_SALT, "success", "", "", "", "", "",
             "", "", "", "", udf1, email, firstname, productinfo, amount, txnid, PAYU_KEY]
    digest = sha512("|".join(parts))
    form = {
        "key": PAYU_KEY, "txnid": txnid, "amount": amount, "additionalCharges": ac,
        "productinfo": productinfo, "firstname": firstname, "email": email,
        "udf1": udf1, "udf2": "", "udf3": "", "udf4": "", "udf5": "",
        "status": "success", "mihpayid": "SIMAC456", "hash": digest,
    }
    r = requests.post(f"{API}/payments/payu/success", data=form, allow_redirects=False)
    assert r.status_code == 303, r.text
